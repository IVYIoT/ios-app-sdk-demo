//
//  Constants.h
//  IvyAppDemo
//
//  Created by JackChan on 11/1/2020.
//  Copyright © 2020 JackChan. All rights reserved.
//

#ifndef Constants_h
#define Constants_h

#define kDeviceUID @"3X5R3659ZHY49VCEAIVY929F"
#define kUsername @"1"
#define kPassword @"foscam1"

#define kSSID @""
#define kWiFiPassword @""

#endif /* Constants_h */
