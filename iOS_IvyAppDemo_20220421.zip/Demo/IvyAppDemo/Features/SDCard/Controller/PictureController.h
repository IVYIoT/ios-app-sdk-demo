//
//  PictureController.h
//  IvyAppDemo
//
//  Created by JackChan on 21/12/2020.
//  Copyright © 2020 JackChan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IvyCamera.h"

NS_ASSUME_NONNULL_BEGIN

@interface PictureController : UIViewController

- (instancetype)initWithIvyCamera:(IvyCamera *)ivyCamera;

@end

NS_ASSUME_NONNULL_END
