//
//  HomeController.m
//  IvySdk
//
//  Created by JackChan on 25/6/2019.
//  Copyright © 2019 JackChan. All rights reserved.
//

#import "HomeController.h"
#import "LiveController.h"
#import "WiFiConfiguration.h"
#import "Masonry.h"
#import "IvyCamera.h"
#import "UIImage+IvySdk.h"
#import "GlobalData.h"

static NSString * const kCellID = @"CellID";

@interface HomeController () <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) NSArray<IvyCamera *> *dataSource;

@property (nonatomic, strong) UITableView *tableView;

@end

@implementation HomeController

#pragma mark - Lifecycle
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addDevice)];
    
    [self.view addSubview:self.tableView];
    [self layoutPageSubviews];
    
    [self reloadData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self reloadUI];
}

#pragma mark - Private Methods
- (void)layoutPageSubviews {
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
}

- (void)reloadData {
    self.dataSource = [GlobalData shared].devices;
    
    __weak typeof(self) weakSelf = self;
    for (IvyCamera *obj in self.dataSource) {
        [obj loginCamera:^(IVYIO_HANDLE_STATE handleState, IVYIO_RESULT cmdResult) {
            [weakSelf reloadUI];
        }];
    }
}

- (void)reloadUI {
    [self.tableView reloadData];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellID];
    if (nil == cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:kCellID];
        cell.backgroundColor = RGBCOLOR(250, 250, 250);
    }
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    IvyCamera *obj = self.dataSource[indexPath.row];
    cell.textLabel.text = [NSString stringWithFormat:@"UID:%@", obj.deviceUID];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"Username:%@\tPassword:%@", obj.username, obj.password];
    
    BOOL online = (obj.handleState == IVYIO_HANDLE_STATE_ONLINE);
    cell.backgroundColor = online ? RGBCOLOR(118, 214, 114) : RGBCOLOR(250, 250, 250);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    IvyCamera *obj = self.dataSource[indexPath.row];
    LiveController *vc = [[LiveController alloc] initWithIvyCamera:obj];
    [vc preload];
    [self.navigationController pushViewController:vc animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 64.f;
}

#pragma mark - Event Response
- (void)addDevice {
    WiFiConfiguration *vc = [WiFiConfiguration new];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - Getter && Setter
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.estimatedRowHeight = 0;
        _tableView.estimatedSectionHeaderHeight = 0;
        _tableView.estimatedSectionFooterHeight = 0;
    }
    return _tableView;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
