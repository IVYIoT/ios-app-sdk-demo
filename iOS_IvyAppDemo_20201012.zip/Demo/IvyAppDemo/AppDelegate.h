//
//  AppDelegate.h
//  IvySdk
//
//  Created by JackChan on 11/6/2019.
//  Copyright © 2019 JackChan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

/*
 声波配网
 有感无感密码
 清晰度设置
 夜视红外
 音量控制
 SDCard格式化
 */

@end

