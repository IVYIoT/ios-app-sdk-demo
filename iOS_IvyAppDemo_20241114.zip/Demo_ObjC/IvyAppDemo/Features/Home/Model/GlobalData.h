//
//  GlobalData.h
//  IvyAppDemo
//
//  Created by JackChan on 28/9/2020.
//  Copyright © 2020 JackChan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IvyDevice.h"

NS_ASSUME_NONNULL_BEGIN

@interface GlobalData : NSObject

+ (GlobalData *)shared;

@property (nonatomic, strong) NSArray<id<IvyDevice>> *devices;

- (void)loginCameras;

- (void)destroyCameras;

@end

NS_ASSUME_NONNULL_END
