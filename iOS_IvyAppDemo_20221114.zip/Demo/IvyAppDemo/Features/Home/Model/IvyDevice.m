//
//  IvyDevice.m
//  IvyAppDemo
//
//  Created by JackChan on 11/3/2022.
//  Copyright © 2022 JackChan. All rights reserved.
//

#import "IvyDevice.h"

@implementation IvyCamera (IvyDevice)

- (IVYDeviceType)deviceType {
    return IVYDTCamera;
}

@end



@implementation IvyNVR (IvyDevice)

- (IVYDeviceType)deviceType {
    return IVYDTNVR;
}

@end
