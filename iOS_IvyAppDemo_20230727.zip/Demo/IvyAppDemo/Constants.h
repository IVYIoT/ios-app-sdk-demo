//
//  Constants.h
//  IvyAppDemo
//
//  Created by JackChan on 11/1/2020.
//  Copyright © 2020 JackChan. All rights reserved.
//

#ifndef Constants_h
#define Constants_h

#define kCameraAvailable 1
#define kNVRAvailable 0

#define kCameraDeviceUID @""
#define kCameraUsername @""
#define kCameraPassword @""

#define kNVRDeviceUID @""
#define kNVRUsername @""
#define kNVRPassword @""

#define kSSID @""
#define kWiFiPassword @""

#endif /* Constants_h */
