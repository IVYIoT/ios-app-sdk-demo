//
//  NVRLiveController.m
//  IvyAppDemo
//
//  Created by JackChan on 11/3/2022.
//  Copyright © 2022 JackChan. All rights reserved.
//

#import "NVRLiveController.h"
#import "Masonry.h"
#import "IvyNVRPlayer.h"
#import "UIImage+IvySdk.h"

static NSString * const kCellID = @"CellID";
static NSString * const kCollectionCellID = @"CollectionCellID";
static CGFloat const kItemSpacing = 1;
static CGFloat const kNumberOfItems = 2;

@interface NVRLiveCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView *imageView;

@end

@implementation NVRLiveCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self initializer];
    }
    return self;
}

- (void)initializer {
    self.backgroundColor = [UIColor clearColor];
    
    [self addSubview:self.imageView];
    
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
        make.size.equalTo(self);
    }];
}

- (UIImageView *)imageView {
    if (!_imageView) {
        _imageView = [UIImageView new];
        _imageView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.7];
    }
    return _imageView;
}

@end



@interface NVRLiveController () <UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, UITableViewDataSource, UITableViewDelegate, IvyNVRPlayerDelegate>

@property (nonatomic, strong) IvyNVR *ivyNVR;

@property (nonatomic, strong) IvyNVRLivePlayer *player;

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSArray<IvyNVRChn *> *dataSource;

@property (nonatomic, strong) UICollectionViewFlowLayout *flowLayout;

@property (nonatomic, strong) UICollectionView *collectionView;

@end

@implementation NVRLiveController

- (instancetype)initWithIvyNVR:(IvyNVR *)ivyNVR {
    if (self = [super initWithNibName:nil bundle:nil]) {
        _ivyNVR = ivyNVR;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"NVR Live";
    self.view.backgroundColor = [UIColor whiteColor];
    self.edgesForExtendedLayout = UIRectEdgeBottom;
    
    [self.view addSubview:self.collectionView];
    [self.view addSubview:self.tableView];
    
    [self layoutPageSubviews];
    
    [self getNVRConfigs];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.ivyNVR addEventObserver:self selector:@selector(handleEvent:)];
    
    [self reload];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
 
    [self.player stop];
    [self.ivyNVR removeEventObserver:self];
}

- (void)layoutPageSubviews {
    [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self.view);
        make.height.equalTo(self.view.mas_width).multipliedBy(9 / 16.f);
    }];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.collectionView.mas_bottom);
        make.left.right.bottom.equalTo(self.view);
    }];
}

#pragma mark - Private Methods
- (void)reload {
    [self reloadData];
    [self reloadUI];
}

- (void)reloadData {
    NSMutableArray *mutableArray = [NSMutableArray new];
    
    for (IvyNVRChn *obj in self.ivyNVR.ipcList) {
        if (1 == obj.devInfo.isOnLine) {
            [mutableArray addObject:obj];
        }
    }
    
    _dataSource = [mutableArray copy];
}

- (void)reloadUI {
    [self.tableView reloadData];
}

- (void)getNVRConfigs {
    [self.ivyNVR getDevInfo:^(IvyDevInfo * _Nonnull devInfo, IVYIO_RESULT cmdResult) {
        
    }];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellID];
    if (nil == cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:kCellID];
        cell.backgroundColor = RGBCOLOR(250, 250, 250);
    }
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    IvyNVRChn *obj = self.dataSource[indexPath.row];
    
    cell.textLabel.text = [NSString stringWithFormat:@"Channel:%@", @(obj.devInfo.channel)];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"Mac:%@ Version:%@_%@", obj.devInfo.macAddr, obj.devInfo.sysVer, obj.devInfo.appVer];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 64.f;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return @"Channels";
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    IvyNVRChn *obj = self.dataSource[indexPath.row];
    
    NSInteger channel = obj.devInfo.channel;
    
    [self.player playLive:self.ivyNVR channel:channel streamType:0];
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return kNumberOfItems * kNumberOfItems;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kCollectionCellID forIndexPath:indexPath];
    return cell;
}

#pragma mark - UICollectionViewDelegateFlowLayout
- (void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath {
    
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    NSInteger numberOfItems = kNumberOfItems;

    CGRect rect = collectionView.frame;
    
    CGFloat width = (CGRectGetWidth(rect) - kItemSpacing * (numberOfItems - 1)) / numberOfItems;
    CGFloat height = (CGRectGetHeight(rect) - kItemSpacing * (numberOfItems - 1)) / numberOfItems;
    
    return CGSizeMake(width, height);
}

#pragma mark - Event Response
- (void)handleEvent:(NSDictionary *)eventDict {
    NSInteger eventId = [eventDict[@"eventId"] integerValue];
    NSLog(@"... eventId:%@ eventDict:%@", @(eventId), eventDict);
    switch (eventId) {
        case IVY_CTRL_MSG_IPCLIST_CHG: {
            [self reload];
        }
            break;
            
        default:
            break;
    }
}

#pragma mark - IvyNVRPlayerDelegate
- (void)ivyNVRPlayer:(id<IvyNVRPlayer>)player channel:(NSInteger)channel didReciveFrame:(UIImage *)image isFirstFrame:(BOOL)isFirstFrame {
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:channel inSection:0];
    UICollectionViewCell *cell = [self.collectionView cellForItemAtIndexPath:indexPath];
    if (nil == cell) { return; }
    
    NVRLiveCell *thisCell = (NVRLiveCell *)cell;
    thisCell.imageView.image = image;
}

- (void)ivyNVRPlayer:(id<IvyNVRPlayer>)player channel:(NSInteger)channel playerCommand:(IvyPlayerCommand)command result:(IVYIO_RESULT)result {
    NSLog(@"... NVR Player channel:%@ command:%@ result:%@", @(channel), @(command), @(result));
}

#pragma mark - Getter && Setter
- (IvyNVRLivePlayer *)player {
    if (!_player) {
        _player = [IvyNVRLivePlayer new];
        _player.delegate = self;
    }
    return _player;
}

- (UICollectionViewFlowLayout *)flowLayout {
    if (!_flowLayout) {
        _flowLayout = [UICollectionViewFlowLayout new];
        _flowLayout.minimumLineSpacing = kItemSpacing;
        _flowLayout.minimumInteritemSpacing = kItemSpacing;
    }
    return _flowLayout;
}

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:self.flowLayout];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.backgroundColor = [UIColor clearColor];
        [_collectionView registerClass:[NVRLiveCell class] forCellWithReuseIdentifier:kCollectionCellID];
    }
    return _collectionView;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.estimatedRowHeight = 0;
        _tableView.estimatedSectionHeaderHeight = 0;
        _tableView.estimatedSectionFooterHeight = 0;
    }
    return _tableView;
}

- (void)dealloc {
    NSLog(@"%p %@ dealloc", self, NSStringFromClass([self class]));
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
