//
//  IvyDevice.h
//  IvyAppDemo
//
//  Created by JackChan on 11/3/2022.
//  Copyright © 2022 JackChan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IvyCamera.h"
#import "IvyNVR.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, IVYDeviceType) {
    IVYDTCamera,
    IVYDTNVR,
};

@protocol IvyDevice <NSObject>

@property (nonatomic, assign, readonly) IVYDeviceType deviceType;

@end



@interface IvyCamera (IvyDevice)

@end



@interface IvyNVR (IvyDevice)

@end

NS_ASSUME_NONNULL_END
