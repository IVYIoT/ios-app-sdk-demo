//
//  NVRLiveController.h
//  IvyAppDemo
//
//  Created by JackChan on 11/3/2022.
//  Copyright © 2022 JackChan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IvyNVR.h"

NS_ASSUME_NONNULL_BEGIN

@interface NVRLiveController : UIViewController

- (instancetype)initWithIvyNVR:(IvyNVR *)ivyNVR;

@end

NS_ASSUME_NONNULL_END
