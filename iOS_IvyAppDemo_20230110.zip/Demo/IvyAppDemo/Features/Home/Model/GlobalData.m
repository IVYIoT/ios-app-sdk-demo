//
//  GlobalData.m
//  IvyAppDemo
//
//  Created by JackChan on 28/9/2020.
//  Copyright © 2020 JackChan. All rights reserved.
//

#import "GlobalData.h"
#import "Constants.h"

@implementation GlobalData

+ (GlobalData *)shared {
    static GlobalData *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [[GlobalData alloc] init];
    });
    return shared;
}

- (instancetype)init {
    if (self = [super init]) {
        [self initialzier];
    }
    return self;
}

- (void)initialzier {
    NSMutableArray *mutableArray = [NSMutableArray new];
    if (kCameraAvailable) { // Camera
        NSString *deviceUID = kCameraDeviceUID;
        NSString *username = kCameraUsername;
        NSString *password = kCameraPassword;
        IvyCamera *obj = [[IvyCamera alloc] initWithDeviceUID:deviceUID username:username password:password];
        [mutableArray addObject:obj];
    }
    
    if (kNVRAvailable) { // NVR
        NSString *deviceUID = kNVRDeviceUID;
        NSString *username = kNVRUsername;
        NSString *password = kNVRPassword;
        IvyNVR *obj = [[IvyNVR alloc] initWithDeviceUID:deviceUID username:username password:password];
        [mutableArray addObject:obj];
    }
    
    _devices = [mutableArray copy];
}

- (void)preConnect {
    for (id<IvyDevice> device in self.devices) {
        switch (device.deviceType) {
            case IVYDTCamera: {
                IvyCamera *obj = (IvyCamera *)device;
                
                NSString *deviceUID = obj.deviceUID;
                [obj loginCamera:^(IVYIO_HANDLE_STATE handleState, IVYIO_RESULT cmdResult) {
                    NSLog(@"... loginCamera End handleState:%@ cmdResult:%@ deviceUID:%@", @(handleState), @(cmdResult), deviceUID);
                }];
            }
                break;
                
            case IVYDTNVR: {
                IvyNVR *obj = (IvyNVR *)device;
                
                NSString *deviceUID = obj.deviceUID;
                [obj loginNVR:^(IVYIO_HANDLE_STATE handleState, IVYIO_RESULT cmdResult) {
                    NSLog(@"... loginNVR End handleState:%@ cmdResult:%@ deviceUID:%@", @(handleState), @(cmdResult), deviceUID);
                }];
            }
                break;
                
            default:
                break;
        }
    }
}

@end
