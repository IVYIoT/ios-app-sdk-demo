//
//  SDCardController.m
//  IvySdk
//
//  Created by JackChan on 27/6/2019.
//  Copyright © 2019 JackChan. All rights reserved.
//

#import "SDCardController.h"
#import "Masonry.h"
#import <IvySdk/IvySdk.h>
#import "UIImage+IvySdk.h"

static NSString * const kCellID = @"CellID";

@interface IvyRecordObject0 (Helper)

@property (nonatomic, strong, readonly) NSString *timeStr;

@end

@implementation IvyRecordObject0 (Helper)

- (NSString *)timeStr {
    static NSDateFormatter *formatter = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        formatter = [NSDateFormatter new];
        [formatter setDateFormat:@"HH:mm:ss"];
    });
    
    NSString *stStr = [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:self.sTime]];
    NSString *etStr = [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:self.eTime]];
    
    NSString *timeStr = [NSString stringWithFormat:@"%@~%@", stStr, etStr];
    return timeStr;
}

@end

@interface SDCardController () <IvySDPlayerDelegate, UITableViewDataSource, UITableViewDelegate, IvySDDownloaderDelegate>

@property (nonatomic, strong) IvyCamera *ivyCamera;

@property (nonatomic, strong) UIImageView *imageView;

@property (nonatomic, strong) IvySDPlayer *player;

@property (nonatomic, strong) NSArray<id<IvyRecordObject>> *records;

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, assign) BOOL isFinished;

@property (nonatomic, strong) UIButton *playButton;

@property (nonatomic, strong) UILabel *label;

@end

@implementation SDCardController

- (instancetype)initWithIvyCamera:(IvyCamera *)ivyCamera {
    if (self = [super initWithNibName:nil bundle:nil]) {
        _ivyCamera = ivyCamera;
        _isFinished = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"SD Card Playback";
    self.view.backgroundColor = [UIColor whiteColor];
    self.edgesForExtendedLayout = UIRectEdgeBottom;
    
    [self.view addSubview:self.imageView];
    [self.imageView addSubview:self.playButton];
    [self.imageView addSubview:self.label];
    [self.view addSubview:self.tableView];
    
    [self layoutPageSubviews];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [UIApplication sharedApplication].idleTimerDisabled = YES;
    
    __weak typeof(self) weakSelf = self;
    [self.ivyCamera loginCamera:^(IVYIO_HANDLE_STATE handleState, IVYIO_RESULT cmdResult) {
        if (IVYIO_RESULT_OK == cmdResult) {
            [weakSelf getRecordList];
        } else {
            NSLog(@"... 设备不在线");
        }
    }];
    
    [self.player stop];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self.player stop];
}

- (void)layoutPageSubviews {
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self.view);
        make.height.equalTo(self.view.mas_width).multipliedBy(9 / 16.f);
    }];
    
    [self.playButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.imageView).offset(10);
        make.bottom.equalTo(self.imageView).offset(-10);
        make.size.mas_equalTo(CGSizeMake(88, 44));
    }];
    
    [self.label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.right.equalTo(self.imageView).offset(-5);
        make.size.mas_equalTo(CGSizeMake(200, 24));
    }];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.imageView.mas_bottom);
        make.left.bottom.right.equalTo(self.view);
    }];
}

#pragma mark - Private Methods
- (void)test {
    [self.ivyCamera getMotionDetectConfig:^(id<IvyMotionDetect>  _Nullable config, IVYIO_RESULT cmdResult) {
        NSLog(@"");
    }];
    
    [self.ivyCamera getSDCardInfo:^(IvySDInfo * _Nonnull ivySDInfo, IVYIO_RESULT cmdResult) {
        NSLog(@"");
    }];
}

- (void)getRecordList {
    NSInteger year, month, day;
//    NSInteger recordType = 2;
    NSInteger recordType = 511;
    
    {
        NSDate *date = [NSDate date];
        NSCalendar *calendar = [NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian];
        calendar.timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
        NSDateComponents *components = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay fromDate:date];
        
        year = components.year;
        month = components.month;
        day = components.day;
    }
//    day = 17;
    NSLog(@"... getRecordList:%@-%@-%@ recordType:%@", @(year), @(month), @(day), @(recordType));
    
    NSDateComponents *components = [[NSDateComponents alloc] init];
    
    components.year = year;
    components.month = month;
    components.day = day;
    components.minute = 0;
    components.second = 0;
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDate *date = [calendar dateFromComponents:components];
    
    NSInteger GMT = [[NSTimeZone localTimeZone] secondsFromGMTForDate:[NSDate date]];
    
    NSUInteger st = (unsigned int)[date timeIntervalSince1970] + GMT;
    NSUInteger et = st + 24 * 3600 - 1;
    
    __weak typeof(self) weakSelf = self;
    NSLog(@"... st:%@ et:%@", @(st), @(et));
    [self.ivyCamera getSDCardRecordList:st endTime:et recordType:recordType onCompletion:^(id  _Nullable obj, IVYIO_RESULT cmdResult) {
        if (IVYIO_RESULT_OK == cmdResult) {
            NSArray *records = (NSArray *)obj;
            NSLog(@"... getRecordList records count:%@", @([records count]));
            
            weakSelf.records = records;
            [weakSelf reload];
        } else {
            NSLog(@"... getRecordList cmdResult:%@", @(cmdResult));
        }
    }];
}

- (void)playBack:(id<IvyRecordObject>)obj {
    if (nil == obj) { return; }
    
    self.isFinished = NO;
    [self.player playBack:self.ivyCamera recordObject:obj decodeType:IvyVideoDecodeUIImage];
    self.player.validAudio = YES;
}

- (void)downloadWithObject:(id<IvyRecordObject>)obj {
    if ([IvySDDownloader shared].isDownloading) {
        NSLog(@"... downloading");
        return;
    }

    NSURL *locationURL = nil;
    
    switch (obj.type) {
        case IvyRecordType0: {
            IvyRecordObject0 *model = (IvyRecordObject0 *)obj;
            
            NSString *locationStr = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.mp4", @(model.sTime)]];
            locationURL = [NSURL URLWithString:locationStr];
        }
            break;
            
        case IvyRecordType1: {
            IvyRecordObject1 *model = (IvyRecordObject1 *)obj;
            NSString *filepath = model.filepath;
            NSString *filename = [NSString stringWithFormat:@"%@.mp4", [[filepath componentsSeparatedByString:@"/"].lastObject componentsSeparatedByString:@"."].firstObject];
            NSString *locationStr = [NSTemporaryDirectory() stringByAppendingPathComponent:filename];
            locationURL = [NSURL URLWithString:locationStr];
        }
            break;
    }
    
    NSLog(@"... locationURL:%@", locationURL.absoluteString);
    self.isFinished = NO;

    [IvySDDownloader shared].delegate = self;
    [[IvySDDownloader shared] downloadSDCardRecod:self.ivyCamera recordObject:obj toURL:locationURL];
}

- (void)reload {
    [self.tableView reloadData];
}

#pragma mark - IvySDPlayerDelegate
- (void)ivySDPlayer:(IvySDPlayer *)player didReciveFrame:(UIImage *)image isFirstFrame:(BOOL)isFirstFrame {
    self.imageView.image = image;
    if (isFirstFrame) {
        
    }
}

- (void)ivySDPlayer:(IvySDPlayer *)player playerCommand:(IvyPlayerCommand)command result:(IVYIO_RESULT)result {
    NSLog(@"... command:%@ result:%@", @(command), @(result));
    switch (command) {
        case IvyPlayerOpenVideo: {
            if (result != IVYIO_RESULT_OK) {
                _isFinished = YES;
            }
        }
            break;
            
        case IvyPlayerCloseVideo: {
            _isFinished = YES;
        }
            break;
            
        case IvyPlayerPause: {
            self.playButton.enabled = YES;
            if (IVYIO_RESULT_OK == result) {
                self.playButton.selected = YES;
            }
        }
            break;
        
        case IvyPlayerResume: {
            self.playButton.enabled = YES;
            if (IVYIO_RESULT_OK == result) {
                self.playButton.selected = NO;
            }
        }
            break;
            
        case IvyPlayerStopped: {
            _isFinished = YES;
        }
            break;
        
        default:
            break;
    }
}

- (void)ivySDPlayer:(IvySDPlayer *)player totalTime:(NSTimeInterval)totalTime timePosition:(NSTimeInterval)timePosition {
    if (fabs(totalTime - timePosition) < 0.01) {
        NSLog(@"... did finish");
    }
}

- (void)ivySDPlayer:(IvySDPlayer *)player bufferingProgress:(CGFloat)progress {
    NSLog(@"... buffering progress:%@", @(progress));
    NSString *text = [NSString stringWithFormat:@"%.2f%%", progress * 100];
    self.label.text = fabs(progress - 1) < 0.01 ? @"" : text;
}

- (void)ivySDPlayer:(IvySDPlayer *)player mediaTransmitSpeed:(NSUInteger)transmitSpeed {
    NSString *text = nil;
    CGFloat mb = transmitSpeed / (1024.f * 1024.f);
    if (mb > 1) {
        text = [NSString stringWithFormat:@"%4.1fMB", mb];
    } else {
        CGFloat kb = transmitSpeed / 1024.f;
        text = [NSString stringWithFormat:@"%4.1fKB",kb];
    }
    
//    self.label.text = text;
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.records.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellID];
    if (nil == cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:kCellID];
    }
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    id<IvyRecordObject> obj = self.records[indexPath.row];
    switch (obj.type) {
        case IvyRecordType0: {
            IvyRecordObject0 *model = (IvyRecordObject0 *)obj;
            NSString *detailDesc = [NSString stringWithFormat:@"%@s", @(model.eTime - model.sTime)];
            cell.textLabel.text = model.timeStr;
            cell.detailTextLabel.text = detailDesc;
        }
            break;
            
        case IvyRecordType1: {
            IvyRecordObject1 *model = (IvyRecordObject1 *)obj;
            NSString *desc = [model.filepath componentsSeparatedByString:@"/"].lastObject;
            cell.textLabel.text = desc;
        }
            break;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
 
    id<IvyRecordObject> obj = self.records[indexPath.row];
    
    NSString *message = nil;
    switch (obj.type) {
        case IvyRecordType0:
            message = [NSString stringWithFormat:@"%@", ((IvyRecordObject0 *)obj).timeStr];
            break;
            
        default:
            break;
    }
    
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"Operation" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alertVC addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alertVC addAction:[UIAlertAction actionWithTitle:(self.isFinished ? @"Play" : @"Stop") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        if (!self.isFinished) {
            [self.player stop];
            return;
        }
        [self playBack:obj];
    }]];
    [alertVC addAction:[UIAlertAction actionWithTitle:@"Download" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        if (!self.isFinished) {
            [self.player stop];
            return;
        }
        [self downloadWithObject:obj];
    }]];
    
    alertVC.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:alertVC animated:YES completion:nil];
}

#pragma mark - IvySDDownloaderDelegate
- (void)ivySDDownloader:(IvySDDownloader *)downloader didFinishDownloadingToURL:(NSURL *)location {
    NSLog(@"... ivySDDownloader didFinishDownloadingToURL:%@", location.absoluteString);
    self.label.text = @"Completed";
}

- (void)ivySDDownloader:(IvySDDownloader *)downloader progress:(CGFloat)progress {
    NSLog(@"... ivySDDownloader progress:%@", @(progress));
    NSString *text = [NSString stringWithFormat:@"Progress: %d%%", (int)(progress * 100)];
    self.label.text = text;
}

- (void)ivySDDownloader:(IvySDDownloader *)downloader didFinishDownloadingWithError:(IVYIO_RESULT)result {
    NSLog(@"... ivySDDownloader didFinishDownloadingWithError:%@", @(result));
}

#pragma mark - Event Response
- (void)playButtonTapped:(UIButton *)sender {
    NSLog(@"... playButtonTapped:%@", @(sender.selected));
    
    sender.enabled = NO;
    
    if (!sender.selected) {
        [self.player pause];
    } else {
        [self.player resume];
    }
}

#pragma mark - Getter && Setter
- (UIImageView *)imageView {
    if (!_imageView) {
        _imageView = [UIImageView new];
        _imageView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.1];
        _imageView.userInteractionEnabled = YES;
    }
    return _imageView;
}

- (IvySDPlayer *)player {
    if (!_player) {
        _player = [IvySDPlayer new];
        _player.delegate = self;
    }
    return _player;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.estimatedRowHeight = 0;
        _tableView.estimatedSectionHeaderHeight = 0;
        _tableView.estimatedSectionFooterHeight = 0;
    }
    return _tableView;
}

- (UIButton *)playButton {
    if (!_playButton) {
        _playButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _playButton.layer.cornerRadius = 8;
        _playButton.layer.masksToBounds = YES;
        _playButton.titleLabel.font = [UIFont systemFontOfSize:18];
        [_playButton setTitle:@"Play" forState:UIControlStateNormal];
        [_playButton setTitle:@"Pause" forState:UIControlStateSelected];
        [_playButton setTitleColor:RGBCOLOR(91, 91, 91) forState:UIControlStateNormal];
        [_playButton setTitleColor:RGBCOLOR(91, 91, 91) forState:UIControlStateSelected];
        [_playButton setBackgroundImage:[UIImage imageWithColor:[UIColor colorWithWhite:1 alpha:0.7]] forState:UIControlStateNormal];
        [_playButton setBackgroundImage:[UIImage imageWithColor:[UIColor colorWithWhite:0 alpha:0.3]] forState:UIControlStateDisabled];
        [_playButton addTarget:self action:@selector(playButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _playButton;
}

- (UILabel *)label {
    if (!_label) {
        _label = [UILabel new];
        _label.font = [UIFont systemFontOfSize:12];
        _label.textAlignment = NSTextAlignmentRight;
        _label.textColor = RGBCOLOR(52, 120, 247);
    }
    return _label;
}

- (void)dealloc {
    NSLog(@"... %@ dealloc", NSStringFromClass([self class]));
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
