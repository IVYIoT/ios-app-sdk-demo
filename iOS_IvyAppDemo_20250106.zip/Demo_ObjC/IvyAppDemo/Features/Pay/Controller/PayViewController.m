//
//  PayViewController.m
//  IvyAppDemo
//
//  Created by JackChan on 26/7/2023.
//  Copyright © 2023 JackChan. All rights reserved.
//

#import "PayViewController.h"
#import <WebKit/WebKit.h>
#import "Masonry.h"

#define kBundleId @"com.foscam.Foscam"

@interface PayViewController () <WKNavigationDelegate>

@property (nonatomic, strong) WKWebView *webView;

@end

@implementation PayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.view addSubview:self.webView];
    [self.webView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self loadRequest];
}

- (void)loadRequest {
    NSString *URL = @"https://www.myfoscam.cn/mobile/store_product_cn?clientId=foscloud&openId=5bebe60cfb6b43298f48138787&accessToken=fbcbfabfc92140798c005e2aaadee5ed&ipcMac=C46E7BA34B1B&ipcName=X1&language=CHS&oemCode=&hideTit=1&os=ios&country=CN&appName=Foscam&bundleId=com.foscam.Foscam&supportCvr=0";
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URL]];
    [self.webView loadRequest:request];
}

#pragma mark - WKNavigationDelegate
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation {
    NSURL *URL = webView.URL;
    NSLog(@"... URL:%@", URL.absoluteString);
    
    NSString *urlScheme = [[NSString stringWithFormat:@"%@.myfoscam.cn://", kBundleId] lowercaseString];
    
    if ([[URL absoluteString] rangeOfString:@"fosPayClose"].location != NSNotFound) {
        [self.navigationController popViewControllerAnimated:YES];
        
    } else if ([[URL absoluteString] rangeOfString:urlScheme].location != NSNotFound) {
        NSString *urlStr = [[URL absoluteString] stringByReplacingOccurrencesOfString:urlScheme withString:@"https://"];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlStr]];

        [self.webView loadRequest:request];
        
    }else if ([[URL absoluteString] hasPrefix:@"weixin://"]){
        NSString *urlScheme = @"weixin://";
        BOOL isExist = [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:urlScheme]];
        if (isExist) {
            [[UIApplication sharedApplication] openURL:URL options:@{} completionHandler:NULL];
        }else{
            NSLog(@"... 未安装weixin");
        }
    }
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    decisionHandler(WKNavigationActionPolicyAllow);
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler{
    decisionHandler(WKNavigationResponsePolicyAllow);
}

#pragma mark - Getter & Setter
- (WKWebView *)webView{
    if(!_webView){
        _webView = [WKWebView new];
        _webView.navigationDelegate = self;
        _webView.allowsBackForwardNavigationGestures = YES;
        _webView.allowsLinkPreview = NO;
    }
    return _webView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
