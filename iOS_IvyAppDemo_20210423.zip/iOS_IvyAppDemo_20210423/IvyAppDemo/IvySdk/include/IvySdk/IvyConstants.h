//
//  IvyConstants.h
//  IvySdk
//
//  Created by JackChan on 12/6/2019.
//  Copyright © 2019 ivyiot. All rights reserved.
//

#ifndef IvyConstants_h
#define IvyConstants_h

#import "IvyIoDef.h"
#import "IvyObject.h"

#define IVYHANDLE   IVYIO_HANDLE
#define SAFTYSTRING(aString)    ((aString) ?: @"")

#define BASE_CTRL_MSG 0x07E3
#define BASE_INTERNAL_CMD BASE_CTRL_MSG
#define BASE_INTERNAL_COMMON_CMD BASE_CTRL_MSG + 20000
#define BASE_INTERNAL_EVENT BASE_CTRL_MSG + 40000
#define BASE_THIRD_PART_COMMON_CMD BASE_CTRL_MSG + 6000


// The max is 0xffff(65535)
// Attention! Record error code is begin at 10000, you should skip this value when you define command id
enum
{
    // Internal cmd
    NET_STATE_DISCONNECT = 88,
    NET_STATE_RECONNECT = 89, // IVY Device has no this event, it is reserve
    IVY_CTRL_MSG_EXCHANGE_KEY = BASE_CTRL_MSG,
    IVY_CTRL_MSG_EXCHANGE_KEY_RESP,
    IVY_CTRL_MSG_LOGIN,
    IVY_CTRL_MSG_LOGIN_RESP,
    IVY_CTRL_MSG_LOGOUT,
    IVY_CTRL_MSG_LOGOUT_RESP,
    IVY_CTRL_MSG_OPEN_LIVE_VIDEO,
    IVY_CTRL_MSG_OPEN_LIVE_VIDEO_RESP,
    IVY_CTRL_MSG_CLOSE_LIVE_VIDEO,
    IVY_CTRL_MSG_CLOSE_LIVE_VIDEO_RESP,
    IVY_CTRL_MSG_OPEN_LIVE_AUDIO,
    IVY_CTRL_MSG_OPEN_LIVE_AUDIO_RESP,
    IVY_CTRL_MSG_CLOSE_LIVE_AUDIO,
    IVY_CTRL_MSG_CLOSE_LIVE_AUDIO_RESP,
    IVY_CTRL_MSG_OPEN_TALK,
    IVY_CTRL_MSG_OPEN_TALK_RESP,
    IVY_CTRL_MSG_CLOSE_TALK,
    IVY_CTRL_MSG_CLOSE_TALK_RESP,
    IVY_CTRL_MSG_TALK_FRAME,
    IVY_CTRL_MSG_VIDEO_FRAME,
    IVY_CTRL_MSG_AUDIO_FRAME,
    IVY_CTRL_MSG_PB_VIDEO_FRAME,
    IVY_CTRL_MSG_PB_AUDIO_FRAME,
    IVY_CTRL_MSG_ERROR_REQUEST,
    IVY_CTRL_MSG_UNSUPORT,
    IVY_CTRL_MSG_SERVER_RUNNING_ERR,
    IVY_CTRL_MSG_USR_HEART_BEAT,
    IVY_CTRL_MSG_USR_HEART_BEAT_RESP,
    IVY_CTRL_MSG_MSG_TOKEN_ERR,
    IVY_CTRL_MSG_GET_RECORD_LIST,
    IVY_CTRL_MSG_GET_RECORD_LIST_RESP,
    IVY_CTRL_MSG_RECORD_PLAYCONTROL,
    IVY_CTRL_MSG_RECORD_PLAYCONTROL_RESP,
    IVY_CTRL_MSG_RECORD_ERROR_NO_ENOUGE_SPACE,
    IVY_CTRL_MSG_RECORD_ERROR_MAX_FILE,
    IVY_CTRL_MSG_RECORD_ERROR_SOLUTION_CHG,
    IVY_CTRL_MSG_RECORD_ERROR_FILE_PATH_NOEXIST,
    IVY_CTRL_MSG_RECORD_ERROR_UNKNOW,
    IVY_CTRL_MSG_REQUEST_KEY_FRAME,
    IVY_CTRL_MSG_REQUEST_KEY_FRAME_RESP,
    IVY_CTRL_MSG_DL_VIDEO_FRAME,
    IVY_CTRL_MSG_DL_AUDIO_FRAME,
    IVY_CTRL_MSG_RECORD_DOWNLOAD,
    IVY_CTRL_MSG_RECORD_DOWNLOAD_RESP,
    IVY_CTRL_MSG_RECORD_DOWNLOAD_PROGRESS,
    IVY_CTRL_MSG_COMMIT_FILE,
    IVY_CTRL_MSG_COMMIT_FILE_RESP,
   
    //
    IVY_CTRL_MSG_ADD_ACCOUNT = BASE_CTRL_MSG + 20000,
    IVY_CTRL_MSG_ADD_ACCOUNT_RESP,
    IVY_CTRL_MSG_DEL_ACCOUNT,
    IVY_CTRL_MSG_DEL_ACCOUNT_RESP,
    IVY_CTRL_MSG_CHANGE_USER_INFO,
    IVY_CTRL_MSG_CHANGE_USER_INFO_RESP,
    IVY_CTRL_MSG_GET_DEVINFO,
    IVY_CTRL_MSG_GET_DEVINFO_RESP,
    IVY_CTRL_MSG_SET_DEVINFO = 22027,
    IVY_CTRL_MSG_SET_DEVINFO_RESP,
    IVY_CTRL_MSG_GET_DEVABILITY,
    IVY_CTRL_MSG_GET_DEVABILITY_RESP,
    IVY_CTRL_MSG_SET_FACTORY_ACCOUNT,
    IVY_CTRL_MSG_SET_FACTORY_ACCOUNT_RESP,
    IVY_CTRL_MSG_SET_IOT_OPEN_ID,
    IVY_CTRL_MSG_SET_IOT_OPEN_ID_RESP,
    

    //media
    IVY_CTRL_MSG_SET_VIDEOSTREAM_PARAM = BASE_CTRL_MSG + 22000,
    IVY_CTRL_MSG_SET_VIDEOSTREAM_PARAM_RESP,
    IVY_CTRL_MSG_GET_VIDEOSTREAM_PARAM,
    IVY_CTRL_MSG_GET_VIDEOSTREAM_PARAM_RESP,
    IVY_CTRL_MSG_SET_VIDEOSTREAM_MODE,
    IVY_CTRL_MSG_SET_VIDEOSTREAM_MODE_RESP,
    IVY_CTRL_MSG_GET_VIDEOSTREAM_MODE,
    IVY_CTRL_MSG_GET_VIDEOSTREAM_MODE_RESP,
    IVY_CTRL_MSG_SET_IMAGE_PARAM,
    IVY_CTRL_MSG_SET_IMAGE_PARAM_RESP,
    IVY_CTRL_MSG_GET_IMAGE_PARAM,
    IVY_CTRL_MSG_GET_IMAGE_PARAM_RESP,
    IVY_CTRL_MSG_SET_MOTION_DETECT_CONFIG,
    IVY_CTRL_MSG_SET_MOTION_DETECT_CONFIG_RESP,
    IVY_CTRL_MSG_GET_MOTION_DETECT_CONFIG,
    IVY_CTRL_MSG_GET_MOTION_DETECT_CONFIG_RESP,
    IVY_CTRL_MSG_SET_VIDEO_MIRROR_FLIP,
    IVY_CTRL_MSG_SET_VIDEO_MIRROR_FLIP_RESP,
    IVY_CTRL_MSG_GET_VIDEO_MIRROR_FLIP,
    IVY_CTRL_MSG_GET_VIDEO_MIRROR_FLIP_RESP,
    IVY_CTRL_MSG_SET_ENVIRONMENT,
    IVY_CTRL_MSG_SET_ENVIRONMENT_RESP,
    IVY_CTRL_MSG_GET_ENVIRONMENT,
    IVY_CTRL_MSG_GET_ENVIRONMENT_RESP,
    IVY_CTRL_MSG_SET_OSD_PARAM,
    IVY_CTRL_MSG_SET_OSD_PARAM_RESP,
    IVY_CTRL_MSG_GET_OSD_PARAM,
    IVY_CTRL_MSG_GET_OSD_PARAM_RESP,
    IVY_CTRL_MSG_SET_AUDIO_VOLUME,
    IVY_CTRL_MSG_SET_AUDIO_VOLUME_RESP,
    IVY_CTRL_MSG_GET_AUDIO_VOLUME,
    IVY_CTRL_MSG_GET_AUDIO_VOLUME_RESP,
    IVY_CTRL_MSG_GET_VIDEO_STREAM_ABLITY,
    IVY_CTRL_MSG_GET_VIDEO_STREAM_ABLITY_RESP,
    IVY_CTRL_MSG_SET_DAY_NIGHT_MODE,
    IVY_CTRL_MSG_SET_DAY_NIGHT_MODE_RESP,
    IVY_CTRL_MSG_GET_DAY_NIGHT_MODE,
    IVY_CTRL_MSG_GET_DAY_NIGHT_MODE_RESP,
    IVY_CTRL_MSG_SET_NIGHT_VISION_SCHEDULE,
    IVY_CTRL_MSG_SET_NIGHT_VISION_SCHEDULE_RESP,
    IVY_CTRL_MSG_GET_NIGHT_VISION_SCHEDULE,
    IVY_CTRL_MSG_GET_NIGHT_VISION_SCHEDULE_RESP,
    IVY_CTRL_MSG_SNAP_PICTURE,
    IVY_CTRL_MSG_SNAP_PICTURE_RESP,
    IVY_CTRL_MSG_GET_MUSIC_PLAY_STATE,
    IVY_CTRL_MSG_GET_MUSIC_PLAY_STATE_RESP,
    IVY_CTRL_MSG_SET_MUSIC_PLAY_START,
    IVY_CTRL_MSG_SET_MUSIC_PLAY_START_RESP,
    IVY_CTRL_MSG_SET_MUSIC_PLAY_STOP,
    IVY_CTRL_MSG_SET_MUSIC_PLAY_STOP_RESP,
    IVY_CTRL_MSG_SET_MUSIC_PLAY_PREV,
    IVY_CTRL_MSG_SET_MUSIC_PLAY_PREV_RESP,
    IVY_CTRL_MSG_SET_MUSIC_PLAY_NEXT,
    IVY_CTRL_MSG_SET_MUSIC_PLAY_NEXT_RESP,
    IVY_CTRL_MSG_GET_MUSIC_NAME_LIST,
    IVY_CTRL_MSG_GET_MUSIC_NAME_LIST_RESP,
    IVY_CTRL_MSG_GET_VIDEO_STREAM_PARAM,                                // foscam ipc command
    IVY_CTRL_MSG_GET_VIDEO_STREAM_PARAM_RESP,                            // foscam ipc command
    IVY_CTRL_MSG_GET_VIDEO_STREAM_TYPE,                                    // foscam ipc command
    IVY_CTRL_MSG_GET_VIDEO_STREAM_TYPE_RESP,                            // foscam ipc command
    IVY_CTRL_MSG_GET_DEFRAME_ENABLE,                                    // foscam ipc command
    IVY_CTRL_MSG_GET_DEFRAME_ENABLE_RESP,                                // foscam ipc command
    IVY_CTRL_MSG_GET_MAIN_STREAM_FORMAT,                                // foscam ipc command
    IVY_CTRL_MSG_GET_MAIN_STREAM_FORMAT_RESP,                            // foscam ipc command
    IVY_CTRL_MSG_SET_VIDEO_STREAM_PARAM,                                // foscam ipc command
    IVY_CTRL_MSG_SET_VIDEO_STREAM_PARAM_RESP,                            // foscam ipc command
    IVY_CTRL_MSG_SET_DEFRAME_ENABLE,                                    // foscam ipc command
    IVY_CTRL_MSG_SET_DEFRAME_ENABLE_RESP,                                // foscam ipc command
    IVY_CTRL_MSG_GET_PRIVACY_ZONE_ENABLE,                                // foscam ipc command
    IVY_CTRL_MSG_GET_PRIVACY_ZONE_ENABLE_RESP,                            // foscam ipc command
    IVY_CTRL_MSG_GET_PRIVACY_ZONE,                                        // foscam ipc command
    IVY_CTRL_MSG_GET_PRIVACY_ZONE_RESP,                                    // foscam ipc command
    IVY_CTRL_MSG_SET_PRIVACY_ZONE_ENABLE,                                // foscam ipc command
    IVY_CTRL_MSG_SET_PRIVACY_ZONE_ENABLE_RESP,                            // foscam ipc command
    IVY_CTRL_MSG_SET_PRIVACY_ZONE,                                        // foscam ipc command
    IVY_CTRL_MSG_SET_PRIVACY_ZONE_RESP,                                    // foscam ipc command
    IVY_CTRL_MSG_GET_SNAPSHOT_CONFIG,                                    // foscam ipc command
    IVY_CTRL_MSG_GET_SNAPSHOT_CONFIG_RESP,                                // foscam ipc command
    IVY_CTRL_MSG_SET_SNAPSHOT_CONFIG,                                    // foscam ipc command
    IVY_CTRL_MSG_SET_SNAPSHOT_CONFIG_RESP,                                // foscam ipc command
    
    IVY_CTRL_MSG_SET_VIDEO_STREAM_TYPE,                                    // foscam ipc command
    IVY_CTRL_MSG_GET_MUSIC_LIST,                                        // foscam ipc command
    IVY_CTRL_MSG_GET_MUSIC_LIST_RESP,                                    // foscam ipc command
    
    IVY_CTRL_MSG_DROPBOX_GET_SNAP_CONFIG,                                // For oem Foscam ipc
    IVY_CTRL_MSG_DROPBOX_GET_SNAP_CONFIG_RESP,
    IVY_CTRL_MSG_DROPBOX_SET_SNAP_CONFIG,                                // For oem foscam ipc
    IVY_CTRL_MSG_DROPBOX_SET_SNAP_CONFIG_RESP,



    //system
    IVY_CTRL_MSG_SET_SYSTEM_TIME = BASE_CTRL_MSG + 24000,
    IVY_CTRL_MSG_SET_SYSTEM_TIME_RESP,
    IVY_CTRL_MSG_GET_SYSTEM_TIME,
    IVY_CTRL_MSG_GET_SYSTEM_TIME_RESP,
    IVY_CTRL_MSG_REBOOT_SYSTEM,
    IVY_CTRL_MSG_REBOOT_SYSTEM_RESP,
    IVY_CTRL_MSG_POWEROFF,
    IVY_CTRL_MSG_POWEROFF_RESP,
    IVY_CTRL_MSG_FACTORY_RESET,
    IVY_CTRL_MSG_FACTORY_RESET_RESP,
    IVY_CTRL_MSG_PTZ_CONTROL_CMD,
    IVY_CTRL_MSG_PTZ_CONTROL_CMD_RESP,
    IVY_CTRL_MSG_GET_DISK_INFO,
    IVY_CTRL_MSG_GET_DISK_INFO_RESP,
    IVY_CTRL_MSG_DISK_FORMAT,
    IVY_CTRL_MSG_DISK_FORMAT_RESP,
    IVY_CTRL_MSG_SET_ONLINE_UPGRADE,
    IVY_CTRL_MSG_SET_ONLINE_UPGRADE_RESP,
    IVY_CTRL_MSG_GET_SD_CARD_INFO,
    IVY_CTRL_MSG_GET_SD_CARD_INFO_RESP,
    IVY_CTRL_MSG_SD_CARD_FORMAT,
    IVY_CTRL_MSG_SD_CARD_FORMAT_RESP,
    IVY_CTRL_MSG_SET_UPNP_CONIG,
    IVY_CTRL_MSG_SET_UPNP_CONIG_RESP,
    IVY_CTRL_MSG_GET_UPNP_CONIG,
    IVY_CTRL_MSG_GET_UPNP_CONIG_RESP,
    IVY_CTRL_MSG_SET_LED_CONFIG, // Deprecated
    IVY_CTRL_MSG_SET_LED_CONFIG_RESP, // Deprecated
    IVY_CTRL_MSG_GET_LED_CONFIG, // Deprecated
    IVY_CTRL_MSG_GET_LED_CONFIG_RESP, // Deprecated
    IVY_CTRL_MSG_SET_MAINTAIN_CONFIG,
    IVY_CTRL_MSG_SET_MAINTAIN_CONFIG_RESP,
    IVY_CTRL_MSG_GET_MAINTAIN_CONFIG,
    IVY_CTRL_MSG_GET_MAINTAIN_CONFIG_RESP,
    IVY_CTRL_MSG_SET_SILENT_UPGRADE_CONFIG,
    IVY_CTRL_MSG_SET_SILENT_UPGRADE_CONFIG_RESP,
    IVY_CTRL_MSG_GET_SILENT_UPGRADE_CONFIG,
    IVY_CTRL_MSG_GET_SILENT_UPGRADE_CONFIG_RESP,
    IVY_CTRL_MSG_SWITCH_BUZZER,
    IVY_CTRL_MSG_SWITCH_BUZZER_RESP,
    IVY_CTRL_MSG_GET_BPI_BATTERY_STATUS,
    IVY_CTRL_MSG_GET_BPI_BATTERY_STATUS_RESP,
    IVY_CTRL_MSG_SET_LED_STATE,
    IVY_CTRL_MSG_SET_LED_STATE_RESP,
    IVY_CTRL_MSG_GET_LED_STATE,
    IVY_CTRL_MSG_GET_LED_STATE_RESP,
    IVY_CTRL_MSG_SET_VOICE_STATE,
    IVY_CTRL_MSG_SET_VOICE_STATE_RESP,
    IVY_CTRL_MSG_GET_VOICE_STATE,
    IVY_CTRL_MSG_GET_VOICE_STATE_RESP,
    IVY_CTRL_MSG_SET_NIGHT_LIGHT,
    IVY_CTRL_MSG_SET_NIGHT_LIGHT_RESP,
    IVY_CTRL_MSG_GET_NIGHT_LIGHT,
    IVY_CTRL_MSG_GET_NIGHT_LIGHT_RESP,
    IVY_CTRL_MSG_SET_AUDIO_ENABLE_STATE,                            // only for foscam bpi
    IVY_CTRL_MSG_SET_AUDIO_ENABLE_STATE_RESP,                        // only for foscam bpi
    IVY_CTRL_MSG_GET_AUDIO_ENABLE_STATE,                            // only for foscam bpi
    IVY_CTRL_MSG_GET_AUDIO_ENABLE_STATE_RESP,                        // only for foscam bpi
    IVY_CTRL_MSG_SET_IMAGE_COLOR,                                    // foscam ipc command
    IVY_CTRL_MSG_SET_IMAGE_COLOR_RESP,                                // foscam ipc command
    IVY_CTRL_MSG_SET_WDR,                                            // foscam ipc command
    IVY_CTRL_MSG_SET_WDR_RESP,                                        // foscam ipc command
    IVY_CTRL_MSG_GET_SESSION_LIST,                                    // foscam ipc command
    IVY_CTRL_MSG_GET_SESSION_LIST_RESP,                                // foscam ipc command
    IVY_CTRL_MSG_GET_LOG,                                            // foscam ipc command
    IVY_CTRL_MSG_GET_LOG_RESP,                                        // foscam ipc command
    IVY_CTRL_MSG_GET_USER_LIST,                                        // foscam ipc command
    IVY_CTRL_MSG_GET_USER_LIST_RESP,                                // foscam ipc command
    IVY_CTRL_MSG_GET_PORT_INFO,                                        // foscam ipc command
    IVY_CTRL_MSG_GET_PORT_INFO_RESP,                                // foscam ipc command
    IVY_CTRL_MSG_SET_PORT_INFO,                                        // foscam ipc command
    IVY_CTRL_MSG_SET_PORT_INFO_RESP,                                // foscam ipc command
    IVY_CTRL_MSG_SET_P2P_PORT,                                        // foscam ipc command
    IVY_CTRL_MSG_SET_P2P_PORT_RESP,                                    // foscam ipc command
    IVY_CTRL_MSG_GET_P2P_PORT,                                        // foscam ipc command
    IVY_CTRL_MSG_GET_P2P_PORT_RESP,                                    // foscam ipc command
    IVY_CTRL_MSG_GET_ONVIF_AGENT_STATE,                                // foscam ipc command
    IVY_CTRL_MSG_GET_ONVIF_AGENT_STATE_RESP,                        // foscam ipc command
    IVY_CTRL_MSG_GET_ONVIF_AUTH_REQUIRED,                            // foscam ipc command
    IVY_CTRL_MSG_GET_ONVIF_AUTH_REQUIRED_RESP,                        // foscam ipc command
    IVY_CTRL_MSG_SET_ONVIF_ENABLE,                                    // foscam ipc command
    IVY_CTRL_MSG_SET_ONVIF_ENABLE_RESP,                                // foscam ipc command
    IVY_CTRL_MSG_SET_ONVIF_AUTH_ENABLE,                                // foscam ipc command
    IVY_CTRL_MSG_SET_ONVIF_AUTH_ENABLE_RESP,                        // foscam ipc command
    IVY_CTRL_MSG_IMPORT_CONFIG_FILE,                                // foscam ipc command
    IVY_CTRL_MSG_IMPORT_CONFIG_FILE_RESP,                            // foscam ipc command
    IVY_CTRL_MSG_GET_CONFIG_FILE_NAME,                                // foscam ipc command
    IVY_CTRL_MSG_GET_CONFIG_FILE_NAME_RESP,                            // foscam ipc command
    IVY_CTRL_MSG_UPGRADE_BY_FILE,                                    // foscam ipc command
    IVY_CTRL_MSG_UPGRADE_BY_FILE_RESP,                                // foscam ipc command
    IVY_CTRL_MSG_REMOVE_PATCH,                                        // foscam ipc command
    IVY_CTRL_MSG_REMOVE_PATCH_RESP,                                    // foscam ipc command
    IVY_CTRL_MSG_GET_TIMING_REBOOT,                                    // foscam ipc command
    IVY_CTRL_MSG_GET_TIMING_REBOOT_RESP,                            // foscam ipc command
    IVY_CTRL_MSG_SET_TIMING_REBOOT,                                    // foscam ipc command
    IVY_CTRL_MSG_SET_TIMING_REBOOT_RESP,                            // foscam ipc command
    IVY_CTRL_MSG_GET_DEVICE_STATUS,                                    // foscam ipc command
    IVY_CTRL_MSG_GET_DEVICE_STATUS_RESP,                            // foscam ipc command
    IVY_CTRL_MSG_START_SEND_DEBUG_LOG,
    IVY_CTRL_MSG_START_SEND_DEBUG_LOG_RESP,
    IVY_CTRL_MSG_STOP_SEND_DEBUG_LOG,
    IVY_CTRL_MSG_STOP_SEND_DEBUG_LOG_RESP,
    IVY_CTRL_MSG_SET_TELNET_SWITCH,
    IVY_CTRL_MSG_SET_TELNET_SWITCH_RESP,
    IVY_CTRL_MSG_GET_SDK_VERSION,
    IVY_CTRL_MSG_GET_SDK_VERSION_RESP,
    IVY_CTRL_MSG_SET_DST,                                            // foscam ipc command
    IVY_CTRL_MSG_SET_DST_RESP,                                        // foscam ipc command
    IVY_CTRL_MSG_GET_DST,                                            // foscam ipc command
    IVY_CTRL_MSG_GET_DST_RESP,                                        // foscam ipc command
    IVY_CTRL_MSG_UPGRADE_IPC_BY_FILE,                                // foscam nvr command
    IVY_CTRL_MSG_UPGRADE_IPC_BY_FILE_RESP,                            // foscam nvr command
    IVY_CTRL_MSG_UPGRADE_IPC_ONLINE,                                // foscam nvr command
    IVY_CTRL_MSG_UPGRADE_IPC_ONLINE_RESP,                            // foscam nvr command
    IVY_CTRL_MSG_GET_WDR,                                            // foscam ipc command
    IVY_CTRL_MSG_GET_WDR_RESP,                                        // foscam ipc command
    IVY_CTRL_MSG_GET_IMAGE_COLOR,                                    // foscam ipc command
    IVY_CTRL_MSG_GET_IMAGE_COLOR_RESP,                                // foscam ipc command
    IVY_CTRL_MSG_DOORBELL_UNLOCK,
    IVY_CTRL_MSG_DOORBELL_UNLOCK_RESP,
    IVY_CTRL_MSG_GET_DOORBELL_CALL_STAT,
    IVY_CTRL_MSG_GET_DOORBELL_CALL_STAT_RESP,
    IVY_CTRL_MSG_GET_P2P_TUTK_TO_FOSCAM_FLAG,                            // foscam ipc command
    IVY_CTRL_MSG_GET_P2P_TUTK_TO_FOSCAM_FLAG_RESP,                        // foscam ipc command
    IVY_CTRL_MSG_SWITCH_P2P_TUTK_TO_FOSCAM,                                // foscam ipc command
    IVY_CTRL_MSG_SWITCH_P2P_TUTK_TO_FOSCAM_RESP,                        // foscam ipc command
    
    //record
    IVY_CTRL_MSG_SET_RECORD_INFO = BASE_CTRL_MSG + 26000,
    IVY_CTRL_MSG_SET_RECORD_INFO_RESP,
    IVY_CTRL_MSG_GET_RECORD_INFO,
    IVY_CTRL_MSG_GET_RECORD_INFO_RESP,
    IVY_CTRL_MSG_GET_RECORD_LIST_RESERVE, // reserve
    IVY_CTRL_MSG_GET_RECORD_LIST_RESERVE_RESP, // reserve
    IVY_CTRL_MSG_RECORD_FILES_DOWNLOAD,
    IVY_CTRL_MSG_RECORD_FILES_DOWNLOAD_RESP,
    IVY_CTRL_MSG_RECORD_PLAYCONTROL_RESERVE, // reserve
    IVY_CTRL_MSG_RECORD_PLAYCONTROL_RESERVE_RESP, // reserve
    IVY_CTRL_MSG_SET_RECORD_HAS_AUDIO,
    IVY_CTRL_MSG_SET_RECORD_HAS_AUDIO_RESP,
    IVY_CTRL_MSG_GET_RECORD_HAS_AUDIO,
    IVY_CTRL_MSG_GET_RECORD_HAS_AUDIO_RESP,
    IVY_CTRL_MSG_SET_RECORD_MODE,
    IVY_CTRL_MSG_SET_RECORD_MODE_RESP,
    IVY_CTRL_MSG_GET_RECORD_MODE,
    IVY_CTRL_MSG_GET_RECORD_MODE_RESP,
    IVY_CTRL_MSG_SET_RECORD_STORE_LOCATION,
    IVY_CTRL_MSG_SET_RECORD_STORE_LOCATION_RESP,
    IVY_CTRL_MSG_GET_RECORD_STORE_LOCATION,
    IVY_CTRL_MSG_GET_RECORD_STORE_LOCATION_RESP,
    IVY_CTRL_MSG_SET_ENABLE_ALGORITHM,
    IVY_CTRL_MSG_SET_ENABLE_ALGORITHM_RESP,
    IVY_CTRL_MSG_GET_ENABLE_ALGORITHM,
    IVY_CTRL_MSG_GET_ENABLE_ALGORITHM_RESP,
    IVY_CTRL_MSG_SET_STROGE_CONFIG,
    IVY_CTRL_MSG_SET_STROGE_CONFIG_RESP,
    IVY_CTRL_MSG_GET_STROGE_CONFIG,
    IVY_CTRL_MSG_GET_STROGE_CONFIG_RESP,
    IVY_CTRL_MSG_GET_SCHEDULE_RECORD_CONFIG,                        // foscam ipc command
    IVY_CTRL_MSG_GET_SCHEDULE_RECORD_CONFIG_RESP,                    // foscam ipc command
    IVY_CTRL_MSG_SET_SCHEDULE_RECORD_CONFIG,                        // foscam ipc command
    IVY_CTRL_MSG_SET_SCHEDULE_RECORD_CONFIG_RESP,                    // foscam ipc command
    IVY_CTRL_MSG_DROPBOX_SET_RECORD_PATH,                            // For oem foscam ipc
    IVY_CTRL_MSG_DROPBOX_SET_RECORD_PATH_RESP,



    //network
    IVY_CTRL_MSG_SET_NET_PARAM = BASE_CTRL_MSG + 28000,
    IVY_CTRL_MSG_SET_NET_PARAM_RESP,
    IVY_CTRL_MSG_GET_NET_PARAM,
    IVY_CTRL_MSG_GET_NET_PARAM_RESP,
    IVY_CTRL_MSG_SET_WIFI_PARAM,
    IVY_CTRL_MSG_SET_WIFI_PARAM_RESP,
    IVY_CTRL_MSG_GET_WIFI_PARAM,
    IVY_CTRL_MSG_GET_WIFI_PARAM_RESP,
    IVY_CTRL_MSG_REFRESH_WIFI_AP_LIST,
    IVY_CTRL_MSG_REFRESH_WIFI_AP_LIST_RESP,
    IVY_CTRL_MSG_GET_WIFI_AP_LIST,
    IVY_CTRL_MSG_GET_WIFI_AP_LIST_RESP,
    IVY_CTRL_MSG_TEST_WIFI,
    IVY_CTRL_MSG_TEST_WIFI_RESP,
    IVY_CTRL_MSG_SET_DDNS_CONFIG,
    IVY_CTRL_MSG_SET_DDNS_CONFIG_RESP,
    IVY_CTRL_MSG_GET_DDNS_CONFIG,
    IVY_CTRL_MSG_GET_DDNS_CONFIG_RESP,
    IVY_CTRL_MSG_SET_P2P_INFO,
    IVY_CTRL_MSG_SET_P2P_INFO_RESP,
    IVY_CTRL_MSG_GET_P2P_INFO,
    IVY_CTRL_MSG_GET_P2P_INFO_RESP,
    IVY_CTRL_MSG_SET_NETWORK_ADAPTATION,
    IVY_CTRL_MSG_SET_NETWORK_ADAPTATION_RESP,
    IVY_CTRL_MSG_GET_NETWORK_ADAPTATION,
    IVY_CTRL_MSG_GET_NETWORK_ADAPTATION_RESP,
    IVY_CTRL_MSG_SET_SMTP_CONFIG,                                        // foscam ipc command
    IVY_CTRL_MSG_SET_SMTP_CONFIG_RESP,                                    // foscam ipc command
    IVY_CTRL_MSG_GET_SMTP_CONFIG,                                        // foscam ipc command
    IVY_CTRL_MSG_GET_SMTP_CONFIG_RESP,                                    // foscam ipc command
    IVY_CTRL_MSG_SMTP_TEST,                                                // foscam ipc command
    IVY_CTRL_MSG_SMTP_TEST_RESP,                                        // foscam ipc command
    IVY_CTRL_MSG_SET_FTP_CONFIG,                                        // foscam ipc command
    IVY_CTRL_MSG_SET_FTP_CONFIG_RESP,                                    // foscam ipc command
    IVY_CTRL_MSG_GET_FTP_CONFIG,                                        // foscam ipc command
    IVY_CTRL_MSG_GET_FTP_CONFIG_RESP,                                    // foscam ipc command
    IVY_CTRL_MSG_FTP_TEST,                                                // foscam ipc command
    IVY_CTRL_MSG_FTP_TEST_RESP,                                            // foscam ipc command
    IVY_CTRL_MSG_FTP_START_SERVER,                                        // foscam ipc command
    IVY_CTRL_MSG_SET_MAC_ADDR,
    IVY_CTRL_MSG_SET_MAC_ADDR_RESP,
    IVY_CTRL_MSG_GET_NET_MODE,                                            // foscam ipc command
    IVY_CTRL_MSG_GET_NET_MODE_RESP,                                        // foscam ipc command
    IVY_CTRL_MSG_GET_4G_INFO,
    IVY_CTRL_MSG_GET_4G_INFO_RESP,
    IVY_CTRL_MSG_START_WIFI_ABILITY_TEST,
    IVY_CTRL_MSG_START_WIFI_ABILITY_TEST_RESP,
    IVY_CTRL_MSG_STOP_WIFI_ABILITY_TEST,
    IVY_CTRL_MSG_STOP_WIFI_ABILITY_TEST_RESP,
    IVY_CTRL_MSG_SET_WIFI_AP_INFO,
    IVY_CTRL_MSG_SET_WIFI_AP_INFO_RESP,
    IVY_CTRL_MSG_GET_WIFI_AP_INFO,
    IVY_CTRL_MSG_GET_WIFI_AP_INFO_RESP,
    IVY_CTRL_MSG_GET_CLOUD_ERROR_CODE,
    IVY_CTRL_MSG_GET_CLOUD_ERROR_CODE_RESP,                                // foscam ipc command
    
    //alarm
    IVY_CTRL_MSG_SET_AUDIO_ALARM_CONFIG = BASE_CTRL_MSG + 30000,
    IVY_CTRL_MSG_SET_AUDIO_ALARM_CONFIG_RESP,
    IVY_CTRL_MSG_GET_AUDIO_ALARM_CONFIG,
    IVY_CTRL_MSG_GET_AUDIO_ALARM_CONFIG_RESP,
    IVY_CTRL_MSG_SET_IO_ALARM_CONFIG,
    IVY_CTRL_MSG_SET_IO_ALARM_CONFIG_RESP,
    IVY_CTRL_MSG_GET_IO_ALARM_CONFIG,
    IVY_CTRL_MSG_GET_IO_ALARM_CONFIG_RESP,
    IVY_CTRL_MSG_SET_HUMIDITY_ALARM_CONFIG,
    IVY_CTRL_MSG_SET_HUMIDITY_ALARM_CONFIG_RESP,
    IVY_CTRL_MSG_GET_HUMIDITY_ALARM_CONFIG,
    IVY_CTRL_MSG_GET_HUMIDITY_ALARM_CONFIG_RESP,
    IVY_CTRL_MSG_SET_TEMPERATURE_ALARM_CONFIG,
    IVY_CTRL_MSG_SET_TEMPERATURE_ALARM_CONFIG_RESP,
    IVY_CTRL_MSG_GET_TEMPERATURE_ALARM_CONFIG,
    IVY_CTRL_MSG_GET_TEMPERATURE_ALARM_CONFIG_RESP,
    IVY_CTRL_MSG_CLEAN_IO_ALARM_OUTPUT,
    IVY_CTRL_MSG_CLEAN_IO_ALARM_OUTPUT_RESP,
    IVY_CTRL_MSG_SET_ONE_KEY_ALARM_CONFIG,
    IVY_CTRL_MSG_SET_ONE_KEY_ALARM_CONFIG_RESP,
    IVY_CTRL_MSG_GET_ONE_KEY_ALARM_CONFIG,
    IVY_CTRL_MSG_GET_ONE_KEY_ALARM_CONFIG_RESP,
    IVY_CTRL_MSG_SET_PEDESTRIAN_DECTECT_CONFIG,
    IVY_CTRL_MSG_SET_PEDESTRIAN_DECTECT_CONFIG_RESP,
    IVY_CTRL_MSG_GET_PEDESTRIAN_DECTECT_CONFIG,
    IVY_CTRL_MSG_GET_PEDESTRIAN_DECTECT_CONFIG_RESP,
    IVY_CTRL_MSG_SET_HUMAN_ALARM_CONFIG,
    IVY_CTRL_MSG_SET_HUMAN_ALARM_CONFIG_RESP,
    IVY_CTRL_MSG_GET_HUMAN_ALARM_CONFIG,
    IVY_CTRL_MSG_GET_HUMAN_ALARM_CONFIG_RESP,
    IVY_CTRL_MSG_GET_ALARM_TIME_CONFIG,                                        // foscam ipc command
    IVY_CTRL_MSG_GET_ALARM_TIME_CONFIG_RESP,                                // foscam ipc command
    IVY_CTRL_MSG_SET_ALARM_TIME_CONFIG,                                        // foscam ipc command
    IVY_CTRL_MSG_SET_ALARM_TIME_CONFIG_RESP,                                // foscam ipc command
    IVY_CTRL_MSG_GET_LOCAL_ALARM_TIME_CONFIG,                                // foscam ipc command
    IVY_CTRL_MSG_GET_LOCAL_ALARM_TIME_CONFIG_RESP,                            // foscam ipc command
    IVY_CTRL_MSG_SET_LOCAL_ALRAM_TIME_CONFIG,                                // foscam ipc command
    IVY_CTRL_MSG_SET_LOCAL_ALARM_TIME_CONFIG_RESP,                            // foscam ipc command
    IVY_CTRL_MSG_SET_PC_AUDIO_ALARM_CONFIG,                                    // foscam ipc command
    IVY_CTRL_MSG_SET_PC_AUDIO_ALARM_CONFIG_RESP,                            // foscam ipc command
    IVY_CTRL_MSG_GET_PC_AUDIO_ALARM_CONFIG,                                    // foscam ipc command
    IVY_CTRL_MSG_GET_PC_AUDIO_ALARM_CONFIG_RESP,                            // foscam ipc command
    IVY_CTRL_MSG_SET_ALARM_HTTP_SERVER,                                        // foscam ipc command
    IVY_CTRL_MSG_SET_ALARM_HTTP_SERVER_RESP,                                // foscam ipc command
    IVY_CTRL_MSG_GET_ALARM_HTTP_SERVER,                                        // foscam ipc command
    IVY_CTRL_MSG_GET_ALARM_HTTP_SERVER_RESP,                                // foscam ipc command
    IVY_CTRL_MSG_CHECK_AIWINN_LICENSE,                                        // foscam ipc command
    IVY_CTRL_MSG_CHECK_AIWINN_LICENSE_RESP,                                    // foscam ipc command


    //Foscam Cloud
    IVY_CTRL_MSG_SET_PUSH_CONFIG = BASE_CTRL_MSG + 32000,
    IVY_CTRL_MSG_SET_PUSH_CONFIG_RESP,
    IVY_CTRL_MSG_GET_PUSH_CONFIG,
    IVY_CTRL_MSG_GET_PUSH_CONFIG_RESP,
    IVY_CTRL_MSG_SET_CLOUD_CONFIG,
    IVY_CTRL_MSG_SET_CLOUD_CONFIG_RESP,
    IVY_CTRL_MSG_GET_CLOUD_CONFIG,
    IVY_CTRL_MSG_GET_CLOUD_CONFIG_RESP,
    IVY_CTRL_MSG_SET_RTMP_CONFIG,
    IVY_CTRL_MSG_SET_RTMP_CONFIG_RESP,
    IVY_CTRL_MSG_GET_RTMP_CONFIG,
    IVY_CTRL_MSG_GET_RTMP_CONFIG_RESP,
    IVY_CTRL_MSG_SET_ALEXA_ENABLE,
    IVY_CTRL_MSG_SET_ALEXA_ENABLE_RESP,
    IVY_CTRL_MSG_GET_ALEXA_ENABLE,
    IVY_CTRL_MSG_GET_ALEXA_ENABLE_RESP,
    IVY_CTRL_MSG_SET_ALEXA_SLEEP,
    IVY_CTRL_MSG_SET_ALEXA_SLEEP_RESP,
    IVY_CTRL_MSG_SET_ALEXA_SERVER,
    IVY_CTRL_MSG_SET_ALEXA_SERVER_RESP,
    IVY_CTRL_MSG_GET_ALEXA_STATE,
    IVY_CTRL_MSG_GET_ALEXA_STATE_RESP,
    IVY_CTRL_MSG_SET_ALEXA_WAKEUP,
    IVY_CTRL_MSG_SET_ALEXA_WAKEUP_RESP,
    IVY_CTRL_MSG_TEST_PUSH,
    IVY_CTRL_MSG_TEST_PUSH_RESP,
    IVY_CTRL_MSG_SET_CHANNEL_SVR_EANBLE_BITS,
    IVY_CTRL_MSG_SET_CHANNEL_SVR_EANBLE_BITS_RESP,
    IVY_CTRL_MSG_GET_CHANNEL_SVR_EANBLE_BITS,
    IVY_CTRL_MSG_GET_CHANNEL_SVR_EANBLE_BITS_RESP,
    IVY_CTRL_MSG_DROPBOX_GET_CLOUD_TOKEN,
    IVY_CTRL_MSG_DROPBOX_GET_CLOUD_TOKEN_RESP,                // For OEM foscam ipc
    IVY_CTRL_MSG_DROPBOX_GET_CLOUD_QUOTA,                    // For OEM foscam ipc
    IVY_CTRL_MSG_DROPBOX_GET_CLOUD_QUOTA_RESP,
    IVY_CTRL_MSG_DROPBOX_TEST_CLOUD_SERVER,                    // For OEM foscam ipc
    IVY_CTRL_MSG_DROPBOX_TEST_CLOUD_SERVER_RESP,            // For OEM foscam ipc
    IVY_CTRL_MSG_DROPBOX_GET_CLOUD_CONFIG,                    // For OEM foscam ipc
    IVY_CTRL_MSG_DROPBOX_GET_CLOUD_CONFIG_RESP,
    IVY_CTRL_MSG_DROPBOX_SET_CLOUD_CONFIG,                    // For oem foscam ipc
    IVY_CTRL_MSG_DROPBOX_SET_CLOUD_CONFIG_RESP,



    //NVR
    IVY_CTRL_MSG_ADD_IPC = BASE_CTRL_MSG + 34000,
    IVY_CTRL_MSG_ADD_IPC_RESP,
    IVY_CTRL_MSG_DEL_IPC,
    IVY_CTRL_MSG_DEL_IPC_RESP,
    IVY_CTRL_MSG_GET_IPC_LIST_INFO,
    IVY_CTRL_MSG_GET_IPC_LIST_INFO_RESP,
    IVY_CTRL_MSG_GET_AUDIO_METHOD,                            // Foscam nvr
    IVY_CTRL_MSG_GET_AUDIO_METHOD_RESP,                        // Foscam nvr
    IVY_CTRL_MSG_GET_ONE_IPC_INFO_ON_LIST,                    // Foscam nvr
    IVY_CTRL_MSG_GET_ONE_IPC_INFO_ON_LIST_RESP,                // Foscam nvr
    IVY_CTRL_MSG_GET_WIFI_CHANNEL,                            // Foscam nvr
    IVY_CTRL_MSG_GET_WIFI_CHANNEL_RESP,                        // Foscam nvr
    IVY_CTRL_MSG_SET_WIFI_CHANNEL,                            // Foscam nvr
    IVY_CTRL_MSG_SET_WIFI_CHANNEL_RESP,                        // Foscam nvr
    IVY_CTRL_MSG_GET_INTELLIGET_RECORD,                        // Foscam nvr
    IVY_CTRL_MSG_GET_INTELLIGET_RECORD_RESP,                // Foscam nvr
    IVY_CTRL_MSG_SET_INTELLIGET_RECORD,                        // Foscam nvr
    IVY_CTRL_MSG_SET_INTELLIGET_RECORD_RESP,                // Foscam nvr
    IVY_CTRL_MSG_SET_ENABLE_AUTO_ADD_DEVICES,                // Foscam nvr
    IVY_CTRL_MSG_SET_ENABLE_AUTO_ADD_DEVICES_RESP,            // Foscam nvr
    IVY_CTRL_MSG_GET_ENABLE_AUTO_ADD_DEVICES,                // Foscam nvr
    IVY_CTRL_MSG_GET_ENABLE_AUTO_ADD_DEVICES_RESP,            // Foscam nvr
    IVY_CTRL_MSG_GET_PTZ_ABILITY,                            // Foscam nvr
    IVY_CTRL_MSG_GET_PTZ_ABILITY_RESP,                        // Foscam nvr
    IVY_CTRL_MSG_SET_ENABLE_BUZZER_HDD_LOST,                // Foscam nvr
    IVY_CTRL_MSG_SET_ENABLE_BUZZER_HDD_LOST_RESP,            // Foscam nvr
    IVY_CTRL_MSG_GET_ENABLE_BUZZER_HDD_LOST,                // Foscam nvr
    IVY_CTRL_MSG_GET_ENABLE_BUZZER_HDD_LOST_RESP,            // Foscam nvr
    IVY_CTRL_MSG_SET_ENABLE_BUZZER_HDD_FULL,                        // Foscam nvr
    IVY_CTRL_MSG_SET_ENABLE_BUZZER_HDD_FULL_RESP,                    // Foscam nvr
    IVY_CTRL_MSG_GET_ENABLE_BUZZER_HDD_FULL,                        // Foscam nvr
    IVY_CTRL_MSG_GET_ENABLE_BUZZER_HDD_FULL_RESP,                    // Foscam nvr
    IVY_CTRL_MSG_SET_ENABLE_BUZZER_HDD_ERROR,                        // Foscam nvr
    IVY_CTRL_MSG_SET_ENABLE_BUZZER_HDD_ERROR_RESP,                    // Foscam nvr
    IVY_CTRL_MSG_GET_ENABLE_BUZZER_HDD_ERROR,                        // Foscam nvr
    IVY_CTRL_MSG_GET_ENABLE_BUZZER_HDD_ERROR_RESP,                    // Foscam nvr
    IVY_CTRL_MSG_SET_ENABLE_BUZZER_VIDEO_LOST,                        // Foscam nvr
    IVY_CTRL_MSG_SET_ENABLE_BUZZER_VIDEO_LOST_RESP,                    // Foscam nvr
    IVY_CTRL_MSG_GET_ENABLE_BUZZER_VIDEO_LOST,                        // Foscam nvr
    IVY_CTRL_MSG_GET_ENABLE_BUZZER_VIDEO_LOST_RESP,                    // Foscam nvr
    IVY_CTRL_MSG_SET_ENABLE_BUZZER_NET_ERROR,                        // Foscam nvr
    IVY_CTRL_MSG_SET_ENABLE_BUZZER_NET_ERROR_RESP,                    // Foscam nvr
    IVY_CTRL_MSG_GET_ENABLE_BUZZER_NET_ERROR,                        // Foscam nvr
    IVY_CTRL_MSG_GET_ENABLE_BUZZER_NET_ERROR_RESP,                    // Foscam nvr
    IVY_CTRL_MSG_SET_ENABLE_VIDEO_MASK,                                // foscam nvr command
    IVY_CTRL_MSG_SET_ENABLE_VIDEO_MASK_RESP,                        // foscam nvr command
    IVY_CTRL_MSG_GET_ENABLE_VIDEO_MASK,                                // foscam nvr command
    IVY_CTRL_MSG_GET_ENABLE_VIDEO_MASK_RESP,                        // foscam nvr command
    IVY_CTRL_MSG_GET_ACCOUNTS_INFORMATION,                            // foscam nvr
    IVY_CTRL_MSG_GET_ACCOUNTS_INFORMATION_RESP,                        // foscam nvr
    IVY_CTRL_MSG_SET_ACCOUNTS_INFORMATION,                            // foscam nvr
    IVY_CTRL_MSG_SET_ACCOUNTS_INFORMATION_RESP,                        // foscam nvr
    IVY_CTRL_MSG_SET_DISK_INFO,                                        // foscam nvr
    IVY_CTRL_MSG_SET_DISK_INFO_RESP,                                // foscam nvr
    IVY_CTRL_MSG_SEARCH_DEVS_BY_NVR,                                // foscam nvr
    IVY_CTRL_MSG_SEARCH_DEVS_BY_NVR_RESP,                            // foscam nvr
    IVY_CTRL_MSG_GET_STREAM_CAPABILITY,                                // foscam nvr
    IVY_CTRL_MSG_GET_STREAM_CAPBILITY_RESP,                            // foscam nvr

    //Event msg
    IVY_CTRL_MSG_ONLINE_UPGRADE_STATE = BASE_CTRL_MSG + 40000, // 42019
    IVY_CTRL_MSG_IPCLIST_CHG,

    IVY_CTRL_MSG_MIRROR_FLIP_CHG, // for foscam device
    IVY_CTRL_MSG_DAY_NIGHT_MODE_CHG, // (IRCUT? For foscam device)
    IVY_CTRL_MSG_PRESET_CHG, // for foscam device
    IVY_CTRL_MSG_CRUISE_CHG, // for foscam device
    IVY_CTRL_MSG_PRESET_REACHED, // for foscam device
    IVY_CTRL_MSG_CURRENT_CRUISE_MAP_STATE_CHG, // for foscam device
    IVY_CTRL_MSG_EDGE_ARRIVED, // for foscam device
    IVY_CTRL_MSG_START_PLAY_RESULT, // only for foscam device
    IVY_CTRL_MSG_GET_PRODUCT_ALL_INFO, // only for foscam device
    IVY_CTRL_MSG_CHANNEL_STATE_CHG, // no use
    IVY_CTRL_MSG_ARRIVE_MAX_DURATION, // only for foscam bpi
    IVY_CTRL_MSG_EXT_STATE_CHG, // only for foscam bpi
    IVY_CTRL_MSG_STREAM_PARAM_CHG, // only for foscam ipc
    IVY_CTRL_MSG_SUB_STREAM_PARAM_CHG, // only for foscam ipc
    IVY_CTRL_MSG_STREAM_TYPE_CHG, // only for foscam ipc
    IVY_CTRL_MSG_SUB_STREAM_TYPE_CHG, // only for foscam ipc
    IVY_CTRL_MSG_ABILITY_CHG, // Foscam NVR BPI use, maybe IVY Nvr use
    IVY_CTRL_MSG_VOLUME_CHG, // Foscam IPC use
    IVY_CTRL_MSG_RECORD_ERROR_NO_ENOUGE_SPACE_RESERVE, // not use
    IVY_CTRL_MSG_RECORD_ERROR_MAX_FILE_RESERVE, // not use
    IVY_CTRL_MSG_RECORD_ERROR_SOLUTION_CHG_RESERVE,   // not use
    IVY_CTRL_MSG_RECORD_ERROR_FILE_PATH_NOEXIST_RESERVE,  // not use
    IVY_CTRL_MSG_RECORD_ERROR_UNKNOW_RESERVE, // not use
    IVY_CTRL_MSG_MUSIC_STATE_CHG, // Foscam IPC use
    IVY_CTRL_MSG_BIND_DEVICE_STATE_CHG, // Foscam BPI use, mybe IVY BPI use
    IVY_CTRL_MSG_STREAM_MODE_CHG,//for Ivy device
    IVY_CTRL_MSG_ALARM_CHG,                    // For foscam ipc
    IVY_CTRL_MSG_IMPORT_CFG_RESULT_CHG, // For foscam ipc
    IVY_CTRL_MSG_PC_ALARM_CHG, // For foscam ipc
    IVY_CTRL_MSG_IMAGE_COLOR_CHG, // For foscam ipc
    IVY_CTRL_MSG_WDR_CHG, // For foscam ipc
    IVY_CTRL_MSG_DOORBELL_CALL_STATUS, //For Ivy Sdk,  anposi doorbell
    IVY_CTRL_MSG_WHITE_LIGHT_STATE_CHG // For foscam ipc

    // Internal common cmd for third part
    //BASE_CTRL_MSG + 60000
};

// PTZ CMD
typedef enum
{
    IVY_PTZ_STOP = 0, // 0
    IVY_PTZ_RESET,  // 1
    IVY_PTZ_MOVE_UP, // 2
    IVY_PTZ_MOVE_DOWN, // 3
    IVY_PTZ_MOVE_LEFT, // 4
    IVY_PTZ_MOVE_RIGHT, // 5
    IVY_PTZ_MOVE_LEFTUP, // 6
    IVY_PTZ_MOVE_LEFTDOWN, // 7
    IVY_PTZ_MOVE_RIGHTUP, // 8
    IVY_PTZ_MOVE_RIGHTDOWN, // 9
    IVY_PTZ_SET_SPEED, // 10
    IVY_PTZ_ZOOM_IN, // 11
    IVY_PTZ_ZOOM_OUT, // 12
    IVY_PTZ_ZOOM_STOP, // 13
    IVY_PTZ_SET_ZOOM_SPEED, //14
    IVY_PTZ_GET_ZOOM_SPEED, // 15
    IVY_PTZ_FOCUS_NEAR, // 16
    IVY_PTZ_FOCUS_FAR, // 17
    IVY_PTZ_FOCUS_STOP, // 18
    IVY_PTZ_GOTO_SLEEP, // 19
    IVY_PTZ_GOTO_WAKEUP, // 20
    IVY_PTZ_SET_PRESET_POINT, // 21
    IVY_PTZ_GOTO_PRESET_POINT, // 22
    IVY_PTZ_CLEAR_PRESET_POINT, // 23
    IVY_PTZ_GET_PRESET_POINT_LIST, // 24
    IVY_PTZ_SET_GUARD_POSITION, // 25
    IVY_PTZ_GET_GUARD_POSITION, // 26
    IVY_PTZ_START_CRUISE, // 27
    IVY_PTZ_STOP_CRUISE, // 28
    IVY_PTZ_SET_CURISE_MAP, // 29
    IVY_PTZ_CLEAR_CURISE, // 30
    IVY_PTZ_GET_CRUISE_MAP_INFO, // 31
    IVY_PTZ_SET_CURISE_CTRL_TIME, // 32
    IVY_PTZ_GET_CRUISE_MAP_LIST, // 33
    IVY_PTZ_SET_CRUISE_CTRL_MODE, // 34
    IVY_PTZ_GET_CRUISE_CTRL_MODE, // 35
    IVY_PTZ_SET_CRUISE_TIME_CUSTOMED, // 36
    IVY_PTZ_GET_CRUISE_TIME_CUSTOMED, // 37
    IVY_PTZ_SET_CRUISE_TIME, // 38
    IVY_PTZ_GET_CRUISE_TIME, // 39
    IVY_PTZ_SET_SELF_TEST_MODE, // 40
    IVY_PTZ_GET_SELF_TEST_MODE, // 41
    IVY_PTZ_SET_PRE_POINT_FOR_SELF_TEST, // 42
    IVY_PTZ_GET_PRE_POINT_FOR_SELF_TEST, // 43
    IVY_PTZ_GET_SPEED, // 44
    IVY_PTZ_SET_CRUISE_PRESET_POINT_LINGER_TIME, // 45
    IVY_PTZ_GET_CRUISE_PRESET_POINT_LINGER_TIME, // 46
    IVY_PTZ_SET_CRUISE_LOOP_COUNT, // 47
    IVY_PTZ_GET_CRUISE_LOOP_COUNT, // 48
    IVY_PTZ_DEL_CRUISE_MAP_INFO, //49
    
    IVY_PTZ_MAX_CMD = 100
} IVY_PTZ_CMD;

/// 播放器命令
/// - IvyPlayerOpenVideo: 打开视频
/// - IvyPlayerCloseVideo: 关闭视频
/// - IvyPlayerOpenAudio: 打开音频
/// - IvyPlayerCloseAudio: 关闭音频
/// - IvyPlayerOpenTalk: 打开对讲
/// - IvyPlayerCloseTalk: 关闭对讲
/// - IvyPlayerPause: 暂停
/// - IvyPlayerResume: 继续
/// - IvyPlayerSeek: Seek
/// - IvyPlayerFinished: 播放完成
/// - IvyPlayerStopped: 播放器已经停止 （调用stop方法的结果回调）
typedef NS_ENUM(NSInteger, IvyPlayerCommand) {
    IvyPlayerOpenVideo,
    IvyPlayerCloseVideo,
    IvyPlayerOpenAudio,
    IvyPlayerCloseAudio,
    IvyPlayerOpenTalk,
    IvyPlayerCloseTalk,
    IvyPlayerPause,
    IvyPlayerResume,
    IvyPlayerSeek,
    IvyPlayerFinished,
    IvyPlayerStopped,
};

/// 设备类型
/// - IvyDeviceIVY: IVY设备
/// - IvyDeviceFOS: FOS设备
typedef NS_ENUM(NSInteger, IvyDeviceType) {
    IvyDeviceIVY,
    IvyDeviceFOS,
};

/// 设备清晰度类型
/// - IvyDefinitionSD: SD
/// - IvyDefinitionHD: HD
/// - IvyDefinitionFHD: FHD
/// - IvyDefinitionQHD: QHD
typedef NS_ENUM(NSInteger, IvyDefinitionType) {
    IvyDefinitionSD,
    IvyDefinitionHD,
    IvyDefinitionFHD,
    IvyDefinitionQHD,
};

/// 视频数据解码类型
/// - IvyVideoDecodeUIImage: UIImage
/// - IvyVideoDecodeRawData: H264、H265数据
/// - IvyVideoDecodeYUV420: YUV420
/// - IvyVideoDecodeYUYV422: YUYV422
/// - IvyVideoDecodeUYVY422: UYVY422
/// - IvyVideoDecodeRGB24: RGB24
/// - IvyVideoDecodeBGR24: BGR24
/// - IvyVideoDecodeRGBA32: RGBA32
/// - IvyVideoDecodeARGB32: ARGB32
/// - IvyVideoDecodeABGR32: ABGR32
/// - IvyVideoDecodeBGRA32: BGRA32
/// - IvyVideoDecodeRGB565BE: RGB565BE
/// - IvyVideoDecodeRGB565LE: RGB565LE
/// - IvyVideoDecodeBGR565BE: BGR565BE
/// - IvyVideoDecodeBGR565LE: BGR565LE
typedef NS_ENUM(NSInteger, IvyVideoDecodeType) {
    IvyVideoDecodeUIImage,
    IvyVideoDecodeRawData,
    
    IvyVideoDecodeYUV420,
    IvyVideoDecodeYUYV422,
    IvyVideoDecodeUYVY422,
    
    IvyVideoDecodeRGB24,
    IvyVideoDecodeBGR24,
    IvyVideoDecodeRGBA32,
    IvyVideoDecodeARGB32,
    IvyVideoDecodeABGR32,
    IvyVideoDecodeBGRA32,
    
    IvyVideoDecodeRGB565BE,
    IvyVideoDecodeRGB565LE,
    IvyVideoDecodeBGR565BE,
    IvyVideoDecodeBGR565LE,
};

#endif /* IvyConstants_h */
