//
//  Constants.h
//  IvyAppDemo
//
//  Created by JackChan on 11/1/2020.
//  Copyright © 2020 JackChan. All rights reserved.
//

#ifndef Constants_h
#define Constants_h

#define kDeviceUID @""
#define kUsername @""
#define kPassword @""

#define kSSID @""
#define kWiFiPassword @""

#endif /* Constants_h */
