//
//  LiveController.swift
//  Demo_Swift
//
//  Created by JackChan on 4/11/2024.
//

import UIKit

class LiveController: IVViewController, IvyPlayerDelegate {

    private var device: IvyCamera!
    
    private lazy var ivyPlayer: IvyPlayer = {
        let player = IvyPlayer()
        player.delegate = self
        return player
    }()
    
    private lazy var imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.backgroundColor = UIColor(white: 0, alpha: 0.1)
        return imageView
    }()
    
    init(device: IvyCamera) {
        self.device = device
        
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        view.addSubview(imageView)
        setupConstraints()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        UIApplication.shared.isIdleTimerDisabled = true
        
        NotificationCenter.default.addObserver(self, selector: #selector(didEnterBackgroundNotification), name: UIApplication.didEnterBackgroundNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(didBecomeActiveNotification), name: UIApplication.didBecomeActiveNotification, object: nil)
        
        loginDevice {
            self.ivyPlayer.playLive(self.device, decodeType: .uiImage)
            self.ivyPlayer.validAudio = true
            
            self.fetchConfigs()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        UIApplication.shared.isIdleTimerDisabled = false
        
        ivyPlayer.stop()
    }
    
    // MARK: - Private Methods
    
    private func setupConstraints() {
        imageView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            imageView.heightAnchor.constraint(equalTo: view.widthAnchor, multiplier: 9.0 / 16.0)
        ])
    }
    
    private func loginDevice(success: @escaping () -> Void) {
        device.loginCamera { handleState, cmdResult in
            if IVYIO_RESULT_OK == cmdResult {
                success()
            } else {
                print("... Offline")
            }
        }
    }
    
    private func fetchConfigs() {
        device.getDevInfo { devInfo, cmdResult in
            if IVYIO_RESULT_OK == cmdResult {
                print("firmwareVersion: \(devInfo.firmwareVersion)")
            }
        }
    }
    
    // MARK: - Event Response
    
    @objc private func didEnterBackgroundNotification() {
        ivyPlayer.stop()
    }
    
    @objc private func didBecomeActiveNotification() {
        loginDevice {
            self.ivyPlayer.playLive(self.device, decodeType: .uiImage)
            self.ivyPlayer.validAudio = true
        }
    }
    
    // MARK: - IvyPlayerDelegate
    func ivyPlayer(_ ivyPlayer: IvyPlayer, didReciveFrame image: UIImage, isFirstFrame: Bool) {
        imageView.image = image
    }
    
    func ivyPlayer(_ ivyPlayer: IvyPlayer, playerCommand command: IvyPlayerCommand, result: IVYIO_RESULT) {
        print("... command:\(command.rawValue) result:\(result.rawValue)")
    }
    
    func ivyPlayer(_ ivyPlayer: IvyPlayer, mediaTransmitSpeed transmitSpeed: UInt) {
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
