//
//  GlobalData.swift
//  Demo_Swift
//
//  Created by JackChan on 1/11/2024.
//

import UIKit

class GlobalData: NSObject {
    
    static let shared = GlobalData()
    
    var devices: [IvyCamera] = []
    
    private override init() {
        
        do {
            let deviceUID = "VQ5635624L4KVG8YIIZZZAJB"
            let username = "admin"
            let password = ""
            
            let obj = IvyCamera(deviceUID: deviceUID, username: username, password: password)
            
            devices.append(obj)
        }
    }
    
    func loginDevices() {
        for device in devices {
            let deviceUID = device.deviceUID
            device.loginCamera { handleState, cmdResult in
                let log = "... loginCamera End handleState:\(handleState.rawValue) cmdResult:\(cmdResult.rawValue) deviceUID:\(deviceUID)"
                print(log)
            }
        }
    }
    
    func destroyDevices() {
        for device in devices {
            device.destroy()
        }
    }
}
