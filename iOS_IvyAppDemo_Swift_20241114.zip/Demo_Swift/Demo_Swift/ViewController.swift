//
//  ViewController.swift
//  Demo_Swift
//
//  Created by JackChan on 1/11/2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

}

