//
//  Demo_Swift-Bridging-Header.h
//  Demo_Swift
//
//  Created by JackChan on 1/11/2024.
//

#ifndef Demo_Swift_Bridging_Header_h
#define Demo_Swift_Bridging_Header_h

#import <IvySdk/IvySdk.h>

#endif /* Demo_Swift_Bridging_Header_h */
