//
//  ColorExtension.swift
//  Demo_Swift
//
//  Created by JackChan on 4/11/2024.
//

import UIKit

extension UIColor {
    public convenience init(r: Int, g: Int, b: Int, a: CGFloat) {
        self.init(red: CGFloat(r) / 255.0, 
                  green: CGFloat(g) / 255.0,
                  blue: CGFloat(b) / 255.0,
                  alpha: a)
    }
    
    public convenience init(r: Int, g: Int, b: Int) {
        self.init(red: CGFloat(r) / 255.0,
                  green: CGFloat(g) / 255.0,
                  blue: CGFloat(b) / 255.0,
                  alpha: 1)
    }
}
