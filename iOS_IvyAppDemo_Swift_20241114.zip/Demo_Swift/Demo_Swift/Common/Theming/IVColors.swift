//
//  IVColors.swift
//  Demo_Swift
//
//  Created by JackChan on 4/11/2024.
//

import UIKit

class IVColors {
    static let Black = UIColor(r: 0, g: 0, b: 0)
    static let White = UIColor(r: 250, g: 250, b: 250)
    static let Red = UIColor(r: 250, g: 114 , b: 114)
    static let Green = UIColor(r: 118, g: 214, b: 114)
    
    static let textColor = UIColor(r: 0, g: 0, b: 0, a: 0.9)
    static let detailTextColor = UIColor(r: 0, g: 0, b: 0, a: 0.4)
}
