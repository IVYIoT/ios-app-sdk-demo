//
//  GlobalData.h
//  IvyAppDemo
//
//  Created by JackChan on 28/9/2020.
//  Copyright © 2020 JackChan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IvyCamera.h"

NS_ASSUME_NONNULL_BEGIN

@interface GlobalData : NSObject

+ (GlobalData *)shared;

@property (nonatomic, strong) NSArray<IvyCamera *> *devices;

- (void)preConnect;

@end

NS_ASSUME_NONNULL_END
