//
//  PictureController.m
//  IvyAppDemo
//
//  Created by JackChan on 21/12/2020.
//  Copyright © 2020 JackChan. All rights reserved.
//

#import "PictureController.h"
#import "Masonry.h"

static NSString * const kCellID = @"CellID";

@interface PictureController () <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) IvyCamera *ivyCamera;

@property (nonatomic, strong) UITableView *tableView;

/// 开始时间
@property (nonatomic, assign) unsigned long long st;

/// 结束时间
@property (nonatomic, assign) unsigned long long et;

/// 时间段内总计
@property (nonatomic, assign) NSInteger totalCount;

/// 时间段内当前
@property (nonatomic, assign) NSUInteger curCount;

/// 图片数据
@property (nonatomic, strong) NSMutableArray<IvyPictureInfo *> *dataSource;

@end

@implementation PictureController

- (instancetype)initWithIvyCamera:(IvyCamera *)ivyCamera {
    if (self = [super initWithNibName:nil bundle:nil]) {
        _ivyCamera = ivyCamera;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"Picture";
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(loadMore)];
    
    _dataSource = [NSMutableArray new];
    
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self getPictureList];
}

#pragma mark - Private Methods
- (void)getPictureList {
    NSInteger year, month, day;
    {
        NSDate *date = [NSDate date];
        NSCalendar *calendar = [NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian];
        calendar.timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
        NSDateComponents *components = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay fromDate:date];
        
        year = components.year;
        month = components.month;
        day = components.day;
    }
    
    day = 11;
    
    NSDateComponents *components = [[NSDateComponents alloc] init];
    
    components.year = year;
    components.month = month;
    components.day = day;
    components.minute = 0;
    components.second = 0;
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDate *date = [calendar dateFromComponents:components];
    
    NSUInteger st = (unsigned int)[date timeIntervalSince1970];
    NSUInteger et = st + 24 * 3600 - 1;
    
    _st = st;
    _et = et;
    _curCount = 0;
    
    [self loadSDCardPictureList];
}

- (void)loadSDCardPictureList {
    unsigned long long startTime = _st;
    unsigned long long endTime = _et;
    NSInteger type = 0b111111111;
    NSInteger startNo = _curCount;
    
    [self.ivyCamera getSDCardPictureList:startTime endTime:endTime type:type startNo:startNo onCompletion:^(id  _Nullable obj, IVYIO_RESULT cmdResult) {
        if (cmdResult == IVYIO_RESULT_OK) {
            IvyPictureList *list = (IvyPictureList *)obj;
            NSLog(@"... totalCount:%@ curCount:%@", @(list.totalCount), @(list.curCount));
            
            self.totalCount = list.totalCount;
            self.curCount += list.curCount;
            [self.dataSource addObjectsFromArray:list.list];
            [self reload];
        }
    }];
}

- (void)downloadPicture:(IvyPictureInfo *)info {
    NSString *deviceUID = self.ivyCamera.deviceUID;
    NSString *filename = [NSString stringWithFormat:@"%@_%@.JPG", deviceUID, @(info.time)];
    NSString *filepath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject stringByAppendingPathComponent:filename];
    
    NSLog(@"... download picture time:%@", @(info.time));
    [self.ivyCamera downloadSDCardPicture:info onCompletion:^(id  _Nullable obj, IVYIO_RESULT cmdResult) {
        NSLog(@"... download picture time:%@ finished cmdResult:%@", @(info.time), @(cmdResult));
        
        if (IVYIO_RESULT_OK == cmdResult) {
            NSData *data = (NSData *)obj;
            if (nil != data) {
                BOOL flag = [data writeToFile:filepath atomically:YES];
                if (flag) {
                    NSLog(@"... download picture success");
                }
            }
        }
    }];
}

- (void)reload {
    [self.tableView reloadData];
}

#pragma mark - Event Response
- (void)loadMore {
    if (self.curCount >= self.totalCount) {
        NSLog(@"... No More Data");
        return;
    }
    
    [self loadSDCardPictureList];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellID];
    if (nil == cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:kCellID];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    IvyPictureInfo *obj = self.dataSource[indexPath.row];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@", @(obj.time)];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    IvyPictureInfo *obj = self.dataSource[indexPath.row];
    [self downloadPicture:obj];
}

#pragma mark - Getter && Setter
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.estimatedRowHeight = 0;
        _tableView.estimatedSectionHeaderHeight = 0;
        _tableView.estimatedSectionFooterHeight = 0;
    }
    return _tableView;
}

- (void)dealloc {
    NSLog(@"... %@ dealloc", NSStringFromClass([self class]));
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
