//
//  SDCardController.m
//  IvySdk
//
//  Created by JackChan on 27/6/2019.
//  Copyright © 2019 JackChan. All rights reserved.
//

#import "SDCardController.h"
#import "Masonry.h"
#import "IvySDPlayer.h"

static NSString * const kCellID = @"CellID";

@interface SDCardController () <IvySDPlayerDelegate, UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) IvyCamera *ivyCamera;

@property (nonatomic, strong) UIImageView *imageView;

@property (nonatomic, strong) IvySDPlayer *player;

@property (nonatomic, strong) NSArray<id<IvyRecordObject>> *records;

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, assign) BOOL isFinished;

@end

@implementation SDCardController

- (instancetype)initWithIvyCamera:(IvyCamera *)ivyCamera {
    if (self = [super initWithNibName:nil bundle:nil]) {
        _ivyCamera = ivyCamera;
        _isFinished = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.edgesForExtendedLayout = UIRectEdgeBottom;
    
    [self.view addSubview:self.imageView];
    [self.view addSubview:self.tableView];
    
    [self layoutPageSubviews];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [UIApplication sharedApplication].idleTimerDisabled = YES;
    
    __weak typeof(self) weakSelf = self;
    [self.ivyCamera loginCamera:^(IVYIO_HANDLE_STATE handleState, IVYIO_RESULT cmdResult) {
        if (IVYIO_RESULT_OK == cmdResult) {
            [weakSelf getRecordList];
        } else {
            NSLog(@"... 设备不在线");
        }
    }];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self.player stop];
}

- (void)layoutPageSubviews {
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self.view);
        make.height.equalTo(self.view.mas_width).multipliedBy(9 / 16.f);
    }];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.imageView.mas_bottom);
        make.left.bottom.right.equalTo(self.view);
    }];
}

#pragma mark - Private Methods
- (void)getRecordList {
    NSInteger year, month, day;
//    NSInteger recordType = 2;
    NSInteger recordType = 0b111111111;
    
    {
        NSDate *date = [NSDate date];
        NSCalendar *calendar = [NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian];
        calendar.timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
        NSDateComponents *components = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay fromDate:date];
        
        year = components.year;
        month = components.month;
        day = components.day;
    }
    
    NSLog(@"... getRecordList:%@-%@-%@ recordType:%@", @(year), @(month), @(day), @(recordType));
    
    NSDateComponents *components = [[NSDateComponents alloc] init];
    
    components.year = year;
    components.month = month;
    components.day = day;
    components.minute = 0;
    components.second = 0;
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDate *date = [calendar dateFromComponents:components];
    
    NSUInteger st = (unsigned int)[date timeIntervalSince1970];
    NSUInteger et = st + 24 * 3600 - 1;
    
    __weak typeof(self) weakSelf = self;
    [self.ivyCamera getSDCardRecordList:st endTime:et recordType:recordType onCompletion:^(id  _Nullable obj, IVYIO_RESULT cmdResult) {
        if (IVYIO_RESULT_OK == cmdResult) {
            NSArray *records = (NSArray *)obj;
            NSLog(@"... getRecordList records count:%@", @([records count]));
            
            weakSelf.records = records;
            [weakSelf reload];
        } else {
            NSLog(@"... getRecordList cmdResult:%@", @(cmdResult));
        }
    }];
}

- (void)playBack:(id<IvyRecordObject>)obj {
    if (nil == obj) { return; }
    
    [self.player playBack:self.ivyCamera recordObject:obj decodeType:IvyVideoDecodeUIImage];
    self.player.validAudio = YES;
}

- (void)reload {
    [self.tableView reloadData];
}

#pragma mark - IvySDPlayerDelegate
- (void)ivySDPlayer:(IvySDPlayer *)player didReciveFrame:(UIImage *)image isFirstFrame:(BOOL)isFirstFrame {
    self.imageView.image = image;
    if (isFirstFrame) {
        
    }
}

- (void)ivySDPlayer:(IvySDPlayer *)player playerCommand:(IvyPlayerCommand)command result:(IVYIO_RESULT)result {
    NSLog(@"... command:%@ result:%@", @(command), @(result));
    switch (command) {
        case IvyPlayerOpenVideo: {
            if (result != IVYIO_RESULT_OK) {
                _isFinished = YES;
            }
        }
            break;
            
        case IvyPlayerCloseVideo: {
            _isFinished = YES;
        }
            break;
            
        default:
            break;
    }
}

- (void)ivySDPlayer:(IvySDPlayer *)player totalTime:(NSTimeInterval)totalTime timePosition:(NSTimeInterval)timePosition {
    if (fabs(totalTime - timePosition) < 0.01) {
        self.imageView.image = nil;
        NSLog(@"... 播放完成");
    }
}

- (void)ivySDPlayer:(IvySDPlayer *)player bufferingProgress:(CGFloat)progress {
    NSLog(@"... buffering progress:%@", @(progress));
}

- (void)ivySDPlayer:(IvySDPlayer *)player mediaTransmitSpeed:(NSUInteger)transmitSpeed {
    NSString *text = nil;
    CGFloat mb = transmitSpeed / (1024.f * 1024.f);
    if (mb > 1) {
        text = [NSString stringWithFormat:@"%4.1fMB", mb];
    } else {
        CGFloat kb = transmitSpeed / 1024.f;
        text = [NSString stringWithFormat:@"%4.1fKB",kb];
    }
    
//    NSLog(@"... transmitSpeed:%@", text);
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.records.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellID];
    if (nil == cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:kCellID];
    }
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    id<IvyRecordObject> obj = self.records[indexPath.row];
    switch (obj.type) {
        case IvyRecordType0: {
            IvyRecordObject0 *model = (IvyRecordObject0 *)obj;
            NSString *desc = [NSString stringWithFormat:@"%@~%@", @(model.sTime), @(model.eTime)];
            NSString *detailDesc = [NSString stringWithFormat:@"%@s", @(model.eTime - model.sTime)];
            cell.textLabel.text = desc;
            cell.detailTextLabel.text = detailDesc;
        }
            break;
            
        case IvyRecordType1: {
            IvyRecordObject1 *model = (IvyRecordObject1 *)obj;
            NSString *desc = [model.filepath componentsSeparatedByString:@"/"].lastObject;
            cell.textLabel.text = desc;
        }
            break;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (!_isFinished) {
        [self.player stop];
        return;
    }
    
    id<IvyRecordObject> obj = self.records[indexPath.row];
    [self playBack:obj];
    _isFinished = NO;
}

#pragma mark - Getter && Setter
- (UIImageView *)imageView {
    if (!_imageView) {
        _imageView = [UIImageView new];
        _imageView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.1];
    }
    return _imageView;
}

- (IvySDPlayer *)player {
    if (!_player) {
        _player = [IvySDPlayer new];
        _player.delegate = self;
    }
    return _player;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.estimatedRowHeight = 0;
        _tableView.estimatedSectionHeaderHeight = 0;
        _tableView.estimatedSectionFooterHeight = 0;
    }
    return _tableView;
}

- (void)dealloc {
    NSLog(@"... %@ dealloc", NSStringFromClass([self class]));
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
